﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System.Text.Json;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class CommentController : ControllerBase
    {
        private readonly ICommentService _commentService;
        private readonly ILogService _logger;
        private readonly IPostService _postService;

        public CommentController(ICommentService commentService, ILogService logService, IPostService postService)
        {
            _commentService = commentService;
            _logger = logService;
            _postService = postService;
        }

        [HttpPost("add-comment")]
        public async Task<IActionResult> AddComment([FromBody] AddCommentDTO request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                await _commentService.AddComment(request.PostId, request.UserId, request.CommentText);
                await _logger.CreateLog(request.UserId, $"COMMENT POSTED ON POST({request.PostId}) -> {request.CommentText}", 2);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(request.UserId, "ERROR WHILE ADDING COMMENT TO POST("+ request.PostId + "): " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPost("add-reply")]
        public async Task<IActionResult> AddReply([FromBody] AddCommentDTO request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                await _commentService.AddReply(request.PostId, request.UserId, request.CommentText, (int)request.ParentCommentId);
                await _logger.CreateLog(request.UserId, $"REPLY POSTED OF POST({request.PostId})'S COMMENT({(int)request.ParentCommentId}) -> {request.CommentText}", 2);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(request.UserId, "ERROR WHILE ADDING REPLY TO COMMENT("+ (int)request.ParentCommentId + "): " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/delete-comment/{CommentId}")]
        public async Task<IActionResult> DeleteComment(int CommentId, int UserId)
        {
            try
            {
                await _commentService.DeleteComment(CommentId);
                await _logger.CreateLog(UserId, $"DELETED COMMENT", 2);

                return Ok(new { StatusCode = 200 });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DELETING COMMENT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{UserId}/edit-comment/{CommentId}")]
        public async Task<IActionResult> EditComment(int CommentId, [FromBody] JsonElement payload, int UserId)
        {
            // Extract the value from JsonElement
            if (!payload.TryGetProperty("newCommentText", out JsonElement newCommentTextElement) ||
                string.IsNullOrWhiteSpace(newCommentTextElement.GetString()))
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            string newCommentText = newCommentTextElement.GetString();

            try
            {
                await _commentService.EditComment(CommentId, newCommentText);
                await _logger.CreateLog(UserId, $"EDITED COMMENT({CommentId}) -> {newCommentText}", 2);

                return Ok(new { StatusCode = 200 });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE EDITING COMMENT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }


        [HttpGet("{PostId}/get-comments")]
        public async Task<ActionResult<IEnumerable<CommentDTO>>> GetCommentsByPostId(int PostId)
        {
            int userId = await _postService.GetUserIdByPostId(PostId);
            try
            {
                IEnumerable<CommentDTO> commentDtos = await _commentService.GetCommentsByPostId(PostId);
                
                await _logger.CreateLog(userId, $"FETCHING COMMENTS OF POST({PostId})", 4);

                return Ok(new { StatusCode = 200, commentDtos });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(userId, "ERROR WHILE FETCHING COMMENTS OF POST("+ PostId + "): " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }
    }
}
