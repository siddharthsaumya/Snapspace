﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services;
using Snapspace_Services.Services.IServices;
using System.Collections.Generic;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class NotificationController : ControllerBase
    {
        private readonly INotificationService _notificationService;
        private readonly ILogService _logger;

        public NotificationController(INotificationService notificationService, ILogService logger)
        {
            _notificationService = notificationService;
            _logger = logger;
        }

        [HttpGet("{UserId}/get-notifications")]
        public async Task<IActionResult> GetNotificationsByUserId(int UserId)
        {
            try
            {
                IEnumerable<NotificationDTO> notifications = await _notificationService.GetNotificationsByUserId(UserId);

                if (notifications == null || !notifications.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "FETCHED NOTIFICATIONS", 4);
                return Ok(new { StatusCode = 200, notifications });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING NOTIFICATIONS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-unread-notification-count")]
        public async Task<IActionResult> GetUnreadNotificationCountByUserId(int UserId)
        {
            try
            {
                int unreadCount = await _notificationService.GetUnreadNotificationCountByUserId(UserId);
                return Ok(new { StatusCode = 200, unreadCount });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING UNREAD NOTIFICATION COUNT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }
    }
}
