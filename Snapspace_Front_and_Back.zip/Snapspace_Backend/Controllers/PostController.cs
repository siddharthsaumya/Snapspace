﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services;
using Snapspace_Services.Services.IServices;
using System.Collections.Generic;
using CloudinaryDotNet;
using CloudinaryDotNet.Actions;
using dotenv.net;
using System.Text.Json;


namespace Snapspace_Backend.Controllers
{
    [Route("")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly IPostService _postService;
        private readonly ILogService _logger;

        public PostController(IPostService postService, ILogService logService)
        {
            _postService = postService;
            _logger = logService;
        }

        [HttpPost("create-post")]
        public async Task<IActionResult> CreatePost([FromBody] NewPostDTO newPostDTO)
        {
            if (newPostDTO == null)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                Post createdPost = await _postService.CreatePost(newPostDTO);
                await _logger.CreateLog(newPostDTO.UserId, "NEW POST CREATED("+ createdPost.Id + ")", 2);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(newPostDTO.UserId, "ERROR WHILE CREATING NEW POST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("Please select a file to upload.");
                }


                var filePath = Path.GetTempFileName();


                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }


                Account account = new Account(
                  "djcdrzujw",
                  "639449853639295",
                  "mSetQm56ULJ9j7AYqJUyYXRYcmI");

                Cloudinary cloudinary = new Cloudinary(account);

                var result = cloudinary.Upload(new ImageUploadParams()
                {
                    File = new FileDescription(filePath),
                    PublicId = Guid.NewGuid().ToString()
                });

                System.IO.File.Delete(filePath);

                return Ok(new { result.Url, result.Format,result.StatusCode });
            }
            catch
            {
                return StatusCode(500, "File not uploaded on server");
            }
        }

        [HttpPatch("{PostId}/toggle-archive")]
        public async Task<IActionResult> TogglePostActiveStatus(int PostId)
        {
            int userId = await _postService.GetUserIdByPostId(PostId);
            try
            {
                Post toggledPost = await _postService.TogglePostActiveStatus(PostId);
                if (toggledPost == null)
                {
                    return NotFound(new { StatusCode = 404 });
                }
               
                await _logger.CreateLog(userId, $"ARCHIVED / UNARCHIVED POST({PostId})", 2);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(userId, "ERROR WHILE TOGGLING ARCHIVE: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-archived-posts")]
        public async Task<IActionResult> GetArchivedPostsByUserId(int UserId)
        {
            try
            {
                IEnumerable<PostDTO> posts = await _postService.GetPostsByUserId(UserId, false);

                if (posts == null || !posts.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "CHECK ARCHIVED POSTS", 4);
                return Ok(new { StatusCode = 200, posts });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING ARCHIVED POSTS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{PostId}/update-caption")]
        public async Task<IActionResult> UpdatePostCaption(int PostId, [FromBody] JsonElement payload)
        {
            // Extract the value from JsonElement
            if (!payload.TryGetProperty("newCaption", out JsonElement newCaption) ||
                string.IsNullOrWhiteSpace(newCaption.GetString()))
            {
                return BadRequest(new { StatusCode = 1002 });
            }
            string newCaptionText = newCaption.GetString();
            int userId = await _postService.GetUserIdByPostId(PostId);
            try
            {
                if (string.IsNullOrWhiteSpace(newCaptionText))
                {
                    return BadRequest(new { StatusCode = 1002 });
                }

                bool result = await _postService.UpdatePostCaption(PostId, newCaptionText);
                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }
                
                await _logger.CreateLog(userId, $"CAPTION UPDATED POST({PostId}) -> {newCaptionText}", 2);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(userId, "ERROR WHILE UPDATING THE CAPTION: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-feed")]
        public async Task<IActionResult> GetFollowingPosts(int UserId)
        {
            try
            {
                IEnumerable<PostDTO> posts = await _postService.GetPostsForFollowings(UserId);

                if (posts == null || !posts.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "LOAD FEED", 4);
                return Ok(new { StatusCode = 200, posts });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING THE FEED: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-posts-by-tag/{TagName}")]
        public async Task<IActionResult> GetPostsByTagName(string TagName, int UserId)
        {
            try
            {
                IEnumerable<PostDTO> posts = await _postService.GetPostsByTagName(TagName, UserId);

                if (posts == null || !posts.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "LOAD POSTS FOR TAG("+ TagName + ")", 4);
                return Ok(new { StatusCode = 200, posts });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING POSTS BY TAGNAME: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-post/{PostId}")]
        public async Task<IActionResult> GetPostById(int PostId, int UserId)
        {
            try
            {
                PostDTO post = await _postService.GetPostById(PostId, UserId);

                if (post == null)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, $"VIEWED POST({PostId})", 2);
                return Ok(new { StatusCode = 200, post });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING POST BY POSTID: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/delete-post/{PostId}")]
        public async Task<IActionResult> DeletePostById(int PostId, int UserId)
        {
            try
            {
                PostDTO post = await _postService.GetPostById(PostId, UserId);

                if (post == null)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                // Perform the delete operation
                bool isDeleted = await _postService.DeletePost(PostId);

                if (!isDeleted)
                {
                    return StatusCode(500, new { StatusCode = 500, Message = "Failed to delete the post" });
                }

                await _logger.CreateLog(UserId, $"DELETED POST({PostId})", 2);
                return Ok(new { StatusCode = 200, Message = "Post deleted successfully" });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DELETING POST BY POSTID: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, Message = "An error occurred while deleting the post" });
            }
        }




    }
}
