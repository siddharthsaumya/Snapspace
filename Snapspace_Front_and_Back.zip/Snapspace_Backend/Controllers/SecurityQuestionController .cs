﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System.Collections.Generic;

namespace Snapspace_Backend.Controllers
{
    [Route("")]
    [ApiController]
    public class SecurityQuestionController : ControllerBase
    {
        private readonly ISecurityQuestionService _securityQuestionService;
        private readonly IUserService _userService;
        private readonly ILogService _logger;

        public SecurityQuestionController(ISecurityQuestionService securityQuestionService, ILogService logService, IUserService userService)
        {
            _securityQuestionService = securityQuestionService;
            _logger = logService;
            _userService = userService;
        }

        [HttpGet("get-all-questions")]
        public async Task<IActionResult> GetSecurityQuestions()
        {
            try
            {
                List<SecurityQuestionDTO> questions = await _securityQuestionService.GetSecurityQuestions();

                if (questions == null || !questions.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                return Ok(new { StatusCode = 200, questions });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(-1, "ERROR WHILE FETCHING SECURITY QUESTIONS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPost("{UserId}/add-question")]
        public async Task<IActionResult> CreateSecurityQuestion(CreateSecurityQuestionDTO questionDto, int UserId)
        {
            if (questionDto == null)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _securityQuestionService.CreateSecurityQuestion(questionDto);
                if (!result)
                {
                    return BadRequest(new { StatusCode = 424 });
                }
                await _logger.CreateLog(UserId, "ADDED SECURITY QUESTION( "+ questionDto.Question + " )", 0);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE ADDING NEW SECURITY QUESTION: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-question-answer")]
        public async Task<IActionResult> GetSecurityQuestionAndAnswer(int UserId)
        {
            try
            {
                var result = await _securityQuestionService.GetSecurityQuestionAndAnswer(UserId);

                if (result == null)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                return Ok(new { StatusCode = 200, question = result.Value.Question, answer = result.Value.Answer });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE GETTING SECURITY QESTION'S ANSWER FOR USER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{UserId}/update-question-answer")]
        public async Task<IActionResult> UpdateSecurityQuestionAndAnswer(int UserId, [FromBody] UpdateSecurityQuestionDTO updateSecurityQuestionDTO)
        {
            if (updateSecurityQuestionDTO == null)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _securityQuestionService.UpdateSecurityQuestionAndAnswer(UserId, updateSecurityQuestionDTO);
                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }
                await _logger.CreateLog(UserId, "UPDATED SECURITY QUESTION( "+ updateSecurityQuestionDTO.SecurityQuestionId + " ) ANSWER( "+ updateSecurityQuestionDTO.SecurityAnswer + " )", 0);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE UPDATING SECURITY ANSWER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{Username}/get-security-question")]
        public async Task<IActionResult> GetSecurityQuestion(string Username)
        {
            try
            {
                string? question = await _userService.GetSecurityQuestionByUsername(Username);

                if (question == null)
                {
                    return NotFound(new { StatusCode = 404, Message = "User not found or security question not set" });
                }

                return Ok(new { StatusCode = 200, SecurityQuestion = question });
            }
            catch (Exception ex)
            {
                int userId = await _userService.GetUserIdByUsername(Username);
                await _logger.CreateLog(userId, $"Error fetching security question for {Username}: {ex.Message}",5);
                return StatusCode(500, new { StatusCode = 500, Message = "Internal server error" });
            }
        }

    }
}
