﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services;
using Snapspace_Services.Services.IServices;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class FollowController : ControllerBase
    {
        private readonly IFollowRequestService _followRequestService;
        private readonly IFollowService _followService;
        private readonly INotificationService _notificationService;
        private readonly ILogService _logger;

        public FollowController(INotificationService notificationService, IFollowService followService, IFollowRequestService followRequestService, ILogService logService)
        {
            _followRequestService = followRequestService;
            _followService = followService;
            _notificationService = notificationService;
            _logger = logService;
        }

        [HttpGet("{UserId}/get-pending-requests")]
        public async Task<IActionResult> GetPendingFollowRequests(int UserId)
        {
            try
            {
                IEnumerable<FollowRequestDTO> pendingRequests = await _followRequestService.GetPendingFollowRequests(UserId);

                if (!pendingRequests.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }
                await _logger.CreateLog(UserId, "CHECK PENDING REQUESTS", 4);
                return Ok(new { StatusCode = 200, pendingRequests });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING PENDING REQUEST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-pending-sent-requests")]
        public async Task<IActionResult> GetFollowRequestsSentByUser(int UserId)
        {
            try
            {
                IEnumerable<FollowRequestDTO> followRequests = await _followRequestService.GetFollowRequestsSentByUser(UserId);

                if (!followRequests.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }
                await _logger.CreateLog(UserId, "CHECK SENT REQUESTS", 4);
                return Ok(new { StatusCode = 200, followRequests });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING SENT REQUEST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/unfollow-user/{TargerUserId}")]
        public async Task<IActionResult> UnfollowUser(int UserId, int TargerUserId)
        {
            if (UserId <= 0 || TargerUserId <= 0)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _followService.UnfollowUser(UserId, TargerUserId);

                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }
                await _logger.CreateLog(UserId, $"UNFOLLOWED USER({TargerUserId})", 1);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE UNFOLLOWING USER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/cancel-follow-request/{TargerUserId}")]
        public async Task<IActionResult> DeleteFollowRequest(int UserId, int TargerUserId)
        {
            if (UserId <= 0 || TargerUserId <= 0)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _followRequestService.DeleteFollowRequest(UserId, TargerUserId);

                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, $"CANCEL FOLLOW REQUEST FOR USER ({TargerUserId})", 1);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {

                await _logger.CreateLog(UserId, "ERROR WHILE CANCELING FOLLOW REQUEST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPost("follow-user")]
        public async Task<IActionResult> CreateFollowRequest([FromBody] NewFollowRequestDTO followRequestDTO)
        {
            if (followRequestDTO == null || followRequestDTO.UserId <= 0 || followRequestDTO.FollowUserId <= 0)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _followRequestService.CreateFollowRequest(followRequestDTO);

                if (!result)
                {
                    return BadRequest(new { StatusCode = 424 });
                }

                await _logger.CreateLog(followRequestDTO.UserId, $"FOLLOW REQUESTED FOR USER({followRequestDTO.FollowUserId})", 1);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(followRequestDTO.UserId, "ERROR WHILE FOLLOWING USER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{UserId}/reject-follow-request/{Id}")]
        public async Task<IActionResult> RejectFollowRequest(int Id, int UserId)
        {
            if (Id <= 0)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _followRequestService.RejectFollowRequest(Id);

                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, $"REJECTED FOLLOW REQUEST({Id})", 1);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE REJECTING FOLLOW REQUEST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{UserId}/accept-follow-request/{Id}")]
        public async Task<IActionResult> AcceptFollowRequest(int Id, int UserId)
        {
            if (Id <= 0)
            {
                return BadRequest(new { StatusCode = 1002 });
            }

            try
            {
                bool result = await _followRequestService.AcceptFollowRequest(Id);

                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, $"ACCEPTED FOLLOW REQUEST({Id})",1);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE ACCEPTING FOLLOW REQUEST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-followings")]
        public async Task<ActionResult<IEnumerable<UserSearchDTO>>> GetFollowingUsers(int UserId)
        {
            try
            {
                IEnumerable<UserSearchDTO> followingUsers = await _followService.GetFollowingUsers(UserId);
                if (followingUsers == null || !followingUsers.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "VIEW FOLLOWING LIST", 1);

                return Ok(new { StatusCode = 200, followingUsers });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING FOLLOWING LIST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-followers")]
        public async Task<ActionResult<IEnumerable<UserSearchDTO>>> GetFollowerUsers(int UserId)
        {
            try
            {
                IEnumerable<UserSearchDTO> followerUsers = await _followService.GetFollowerUsers(UserId);
                if (followerUsers == null || !followerUsers.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }

                await _logger.CreateLog(UserId, "VIEW FOLLOWER LIST", 1);

                return Ok(new { StatusCode = 200, followerUsers });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING FOLLOWER LIST: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/is-following/{TargetUserId}")]
        public  IActionResult IsFollowing(int UserId, int TargetUserId)
        {
            try
            {
                bool isFollowing = _followService.IsFollowing(UserId, TargetUserId);
                return Ok(new { StatusCode = 200, isFollowing });
            }
            catch (Exception ex)
            {
                _logger.CreateLog(UserId, "ERROR CHECKING IF USER FOLLOWS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
           
        }
    }
}
