﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class LogController : ControllerBase
    {
        private readonly ILogService _logger;

        public LogController(ILogService logService)
        {
            _logger = logService;
        }

        [HttpGet("{UserId}/get-logs")]
        public async Task<ActionResult<IEnumerable<LogDTO>>> GetLogsByUserId(int UserId)
        {
            try
            {
                IEnumerable<LogDTO> logDTOs = await _logger.GetLogsByUserId(UserId);
                if (logDTOs == null || !logDTOs.Any())
                {
                    return NotFound(new { StatusCode = 404 });
                }
                return Ok(new { StatusCode = 200, logDTOs });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING LOGS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }
    }
}
