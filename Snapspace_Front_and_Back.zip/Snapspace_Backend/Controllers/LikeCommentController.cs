﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System.ComponentModel;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class LikeController : ControllerBase
    {
        private readonly ILikeService _likeService;
        private readonly ILogService _logger;

        public LikeController(ILikeService likeService, ILogService logService)
        {
            _likeService = likeService;
            _logger = logService;
        }

        [HttpPost("toggle-like")]
        public async Task<IActionResult> ToggleLike([FromBody] ToggleLikeDTO request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { StatusCode = 1002 });
            }
            bool isLiked = await _likeService.ToggleLike(request.PostId, request.UserId);
            try
            {
                
                string logMessage = isLiked ? "LIKED" : "UNLIKED";
                await _logger.CreateLog(request.UserId, $"{logMessage} POST - {request.PostId}", 2);

                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                string logMessage = isLiked ? "LIKING" : "DISLIKING";
                await _logger.CreateLog(request.UserId, "ERROR WHILE "+ logMessage + ": " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }
    }
}
