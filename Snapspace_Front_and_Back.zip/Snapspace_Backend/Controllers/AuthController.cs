﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services;
using Snapspace_Services.Services.IServices;

namespace Snapspace_Backend.Controllers
{
    [Route("")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogService _logger;

        public AuthController(IAuthService authService, ILogService logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("login")]
        public async Task<ActionResult<JwtTokenDTO>> Login(LoginDTO request)
        {
            try
            {
                (JwtTokenDTO response,int error) = await _authService.Authenticate(request);
                
                if (response == null)
                {
                    if (error == 404)
                    {
                        return NotFound(new { StatusCode = 404 });
                    }
                    else if (error == 401)
                    {
                        return Unauthorized(new { StatusCode = 1001 });
                    }
                }

               
                return Ok(new {token = response.Token, expiration = response.Expiration, StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(-1, "ERROR WHILE LOGIN: "+ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }

        }


        [HttpPost("register")]
        public async Task<ActionResult<JwtTokenDTO>> Register(RegisterDTO request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(new { StatusCode = 1002 });
                }
                (JwtTokenDTO response,string error) = await _authService.Register(request);
                if (response == null)
                {
                    return BadRequest(new { StatusCode = 403 });
                }
                return Ok(new { token = response.Token, expiration = response.Expiration, StatusCode = 200 });
            }
            catch (Exception ex)
            {
                //await _logger.CreateLog(-1, "ERROR WHILE REGISTERING: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, ex });
            }

        }

        [HttpPost("{UserId}/logout")]
        public async Task<IActionResult> Logout(int UserId)
        {
            try
            {
                bool result = await _authService.Logout(UserId);
                if (result)
                {
                    return Ok(new { StatusCode = 200 });
                }
                else
                {
                    return BadRequest(new { StatusCode = 424 });
                }
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(-1, "ERROR WHILE LOGOUT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }

        }

        [HttpPost("verify-security-answer")]
        public async Task<IActionResult> VerifySecurityAnswer([FromBody] VerifySecurityAnswerDTO model)
        {
            try
            {
                if (model == null)
                {
                    return BadRequest(new { StatusCode = 1002 });
                }
                (bool,int,string) result = await _authService.VerifySecurityAnswer(model.Username, model.Answer);
                if (result.Item1)
                {
                    return Ok(new { StatusCode = 200, result = result.Item1, userId = result.Item2, password = result.Item3 });
                }
                else
                {
                    return BadRequest(new { StatusCode = 424, result = result.Item1 });
                }
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(-1, "ERROR WHILE SECURITY QUESTION ANSWER VERIFICATION: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }
    }
}
