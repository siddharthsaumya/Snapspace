﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;


namespace Snapspace_Backend.Controllers
{
    [Route("")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogService _logger;

        public UserController(IUserService userService, ILogService logService)
        {
            _userService = userService;
            _logger = logService;
        }

        //[HttpGet("get-all-users")]
        //public async Task<ActionResult<IEnumerable<UserDTO>>> GetAllUsers()
        //{
        //    try
        //    {
        //        IEnumerable<UserDTO> users = await _userService.GetAllUsers();
        //        return Ok(new { StatusCode = 200, users });
        //    }
        //    catch (Exception ex)
        //    {
        //        await _logger.CreateLog(-1, "ERROR WHILE FETCHING ALL USER LIST: " + ex, 5);
        //        return StatusCode(500, new { StatusCode = 500 });
        //    }
        //}

        [HttpGet("{UserId}/get-user/{TargetUserId}")]
        public async Task<IActionResult> GetUserById(int UserId, int TargetUserId)
        {
            try
            {
                UserByIdDTO userDto = await _userService.GetUserById(TargetUserId, UserId);
                _logger.CreateLog(UserId, $"PROFILE VISITED - {TargetUserId}", 1);
                return Ok(new { StatusCode = 200, userDto });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { StatusCode = 404});
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING USER DETAIL: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, ex });
            }
        }

        [HttpGet("{UserId}/get-user-info/")]
        public async Task<IActionResult> GetUserInfo(int UserId)
        {
            try
            {
                UserByIdDTO userDto = await _userService.GetUserInfo(UserId);
                return Ok(new { StatusCode = 200, userDto });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING USER DETAIL: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, ex });
            }
        }

        [HttpGet("{Username}/check-username-exists")]
        public async Task<ActionResult<bool>> UsernameExists(string Username)
        {
            try
            {
                Boolean exists = await _userService.UsernameExists(Username);
                return Ok(new { StatusCode = 200, exists });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(-1, "ERROR WHILE CHECKING IF USERNAME EXISTS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }

        }

        [HttpDelete("{UserId}/delete-user")]
        public async Task<ActionResult> DeleteUser(int UserId, [FromBody] PasswordRequestDTO request)
        {
            try
            {
                bool result = await _userService.DeleteUser(UserId, request.Password);
                if (!result)
                {
                    return NotFound(new { StatusCode = 1001 });
                }
               
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DELETING USER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }


        [HttpPatch("{UserId}/update-password")]
        public async Task<IActionResult> UpdatePassword(int UserId, UpdatePasswordDTO request)
        {
            try
            {
                int result = await _userService.UpdatePassword(UserId, request.CurrentPassword, request.NewPassword);

                if (result == 404)
                {
                    return NotFound(new { StatusCode = 404});
                }
                else if (result == 400)
                {
                    return BadRequest(new { StatusCode = 1001 });
                }
                else if (result == 200)
                {
                    _logger.CreateLog(UserId, "PASSWORD UPDATED", 1);
                    return Ok(new { StatusCode = 200 });
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE UPDATING PASSWORD: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPatch("{UserId}/deactivate-user")]
        public async Task<IActionResult> DeactivateUser(int UserId, [FromBody] PasswordRequestDTO request)
        {
            try
            {
                bool result = await _userService.DeactivateUser(UserId, request.Password);
                if (!result)
                {
                    return NotFound(new { StatusCode = 1001 });
                }
                _logger.CreateLog(UserId, "ACCOUNT DEACTIVATED", 1);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DEACTIVATING USER ACCOUNT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }



        [HttpPatch("{UserId}/toggle-online-status")]
        public async Task<IActionResult> ToggleOnlineStatus(int UserId)
        {
            try
            {
                Nullable<bool> currentStatus = await _userService.GetUserOnlineStatus(UserId);

                if (currentStatus == null)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                bool result = await _userService.ToggleUserOnlineStatus(UserId);
                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }

                string logMessage = currentStatus.Value ? "ACCOUNT STATUS OFFLINE" : "ACCOUNT STATUS ONLINE";
                await _logger.CreateLog(UserId, logMessage, 1);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE TOGGLING ONLINE STATUS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPut("{UserId}/update-user-info")]
        public async Task<IActionResult> UpdateUser(int UserId, [FromBody] UpdateUserDTO updateUserDTO)
        {
            if (updateUserDTO == null)
            {
                return BadRequest(new { StatusCode = 1002 });
            }
            try
            {
                bool result = await _userService.UpdateUser(UserId, updateUserDTO);
                if (!result)
                {
                    return NotFound(new { StatusCode = 404 });
                }
                _logger.CreateLog(UserId, "ACCOUNT INFO UPDATED", 1);
                return Ok(new { StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE UPDATING USER DETAILS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpPost("{UserId}/search")]
        public async Task<IActionResult> SearchUsers([FromBody] SearchRequest searchRequest, int UserId)
        {
            try
            {
                IEnumerable<UserSearchDTO> users = await _userService.SearchUsers(searchRequest.SearchTerm);
                _logger.CreateLog(UserId, $"SEARCHED - {searchRequest.SearchTerm}", 4);
                return Ok(new { StatusCode = 200, users });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE SEARCHING USER: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-online-status")]
        public async Task<IActionResult> GetUserOnlineStatus(int UserId)
        {
            try
            {
                Nullable<bool> status = await _userService.GetUserOnlineStatus(UserId);
                return Ok(new { StatusCode = 200, status });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING USER ONLINE STATUS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, ex });
            }
        }

        }
}
