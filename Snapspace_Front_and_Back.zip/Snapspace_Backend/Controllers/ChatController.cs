﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;

namespace Snapspace_Backend.Controllers
{
    [ApiController]
    [Route("")]
    public class ChatController : ControllerBase
    {
        private readonly IChatService _chatService;
        private readonly ILogService _logger;

        public ChatController(IChatService chatService, ILogService logService)
        {
            _chatService = chatService;
            _logger = logService;
        }

        [HttpPost("send-message")]
        public async Task<IActionResult> SendMessage([FromBody] MessageDTO messageDto)
        {
            try
            {
                Message message = await _chatService.SendMessage(messageDto);
                return Ok(new {StatusCode = 200 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(messageDto.SenderId, "ERROR WHILE SENDING MESSAGE: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/delete-message/{MesssageId}")]
        public async Task<IActionResult> DeleteMessage(int MesssageId, int UserId)
        {
            try
            {
                await _chatService.DeleteMessage(MesssageId);
                await _logger.CreateLog(UserId, "DELETE MESSAGE", 3);
                return Ok(new { StatusCode = 200 });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DELETING MESSAGE: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpDelete("{UserId}/delete-chat/{ChatId}")]
        public async Task<IActionResult> DeleteChat(int ChatId,int UserId)
        {
            try
            {
                await _chatService.DeleteChat(ChatId);
                await _logger.CreateLog(UserId, "DELETE CHAT", 3);
                return Ok(new { StatusCode = 200 });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE DELETING CHAT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-chats")]
        public async Task<IActionResult> GetChatsWithUnreadMessageCount(int UserId)
        {
            try
            {
                IEnumerable<ChatDTO> chats = await _chatService.GetChatsWithUnreadMessageCount(UserId);
                await _logger.CreateLog(UserId, "VIEW CHATS", 3);
                return Ok(new { StatusCode = 200, chats });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING CHATS: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-messages/{ChatId}")]
        public async Task<IActionResult> GetChatMessages(int ChatId, int UserId)
        {
            try
            {
                IEnumerable<ChatMessageDTO> messages = await _chatService.GetChatMessages(UserId,ChatId);
                await _logger.CreateLog(UserId, $"VIEW MESSAGES OF CHAT - {ChatId}", 3);
                return Ok(new { StatusCode = 200, messages });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE GETTING MESSAGE OF CHATID("+ ChatId + "): " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-unread-chats-count")]
        public async Task<IActionResult> GetTotalUnreadChatsCount(int UserId)
        {
            try
            {
                IEnumerable<ChatDTO> chats = await _chatService.GetChatsWithUnreadMessageCount(UserId);
                int count = chats.Count(chat => chat.UnreadMessageCount > 0);
                return Ok(new { StatusCode = 200, count });
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { StatusCode = 404 });
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE FETCHING UNREAD CHATS COUNT: " + ex, 5);
                return StatusCode(500, new { StatusCode = 500 });
            }
        }

        [HttpGet("{UserId}/get-chatId/{TargetUserId}")]
        public async Task<IActionResult> CheckChat(int UserId, int TargetUserId)
        {
            try
            {
                var chatDetails = await _chatService.GetChatDetails(UserId, TargetUserId);

                if (chatDetails != null)
                {
                    return Ok(new
                    {
                        chatDetails.ChatId,
                        chatDetails.UserProfilePicture,
                        chatDetails.Username,
                        StatusCode = 200
                    });
                }
                else
                {
                    return NotFound(new { StatusCode = 404 });
                }
            }
            catch (Exception ex)
            {
                await _logger.CreateLog(UserId, "ERROR WHILE GETTING ChatDetails OF USER-1(" + UserId + ") & USER-2(" + TargetUserId + "): " + ex, 5);
                return StatusCode(500, new { StatusCode = 500, ex });
            }
        }



    }

}
