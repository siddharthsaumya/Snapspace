﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.Utils
{
    public class StringFunctions
    {
        public static string CleanString_LowSpaceSymbol(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            string result = input.Trim();
            result = result.ToLower();
            result = result.Replace(" ", string.Empty);
            result = Regex.Replace(result, "[^a-z0-9]", string.Empty);
            return result;
        }

        public static string CleanString_LowSymbol(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            string result = input.Trim();
            result = result.ToLower();
            result = Regex.Replace(result, @"[^a-z0-9#\s]", string.Empty, RegexOptions.IgnoreCase);
            return result;
        }


    }
}
