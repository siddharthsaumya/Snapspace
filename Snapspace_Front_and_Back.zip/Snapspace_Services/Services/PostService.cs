﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Snapspace_Services.Services.Utils;

namespace Snapspace_Services.Services
{
    public class PostService : IPostService
    {
        private readonly IPostRepository _postRepository;
        private readonly IUserRepository _userRepository;
        private readonly IFollowRepository _followRepository;
        private readonly ILikeRepository _likeRepository;
        private readonly ICommentRepository _commentRepository;
        private readonly ITagRepository _tagRepository;
        private readonly INotificationRepository _notificationRepository;

        public PostService(ITagRepository tagRepository, IFollowRepository followRepository, IPostRepository postRepository, IUserRepository userRepository, ILikeRepository likeRepository, ICommentRepository commentRepository,INotificationRepository notificationRepository)
        {
            _followRepository = followRepository;
            _postRepository = postRepository;
            _userRepository = userRepository;
            _likeRepository = likeRepository;
            _commentRepository = commentRepository;
            _tagRepository = tagRepository;
            _notificationRepository = notificationRepository;
        }

        private List<string> ExtractHashtags(string caption)
        {
            List<string> hashtags = new List<string>();
            if (string.IsNullOrWhiteSpace(caption))
                return hashtags;
            string[] words = caption.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string word in words)
            {
                if (word.StartsWith("#"))
                {
                    string hashtag = word.TrimStart('#');
                    hashtags.Add(hashtag);
                }
            }
            return hashtags;
        }

        public async Task<Post> CreatePost(NewPostDTO newPostDTO)
        {
            Post post = new Post
            {
                UserId = newPostDTO.UserId,
                ImageUrl = newPostDTO.ImageUrl,
                Caption = newPostDTO.Caption
            };

            List<string> hashtags = ExtractHashtags(StringFunctions.CleanString_LowSymbol(newPostDTO.Caption));

            Post createdPost = await _postRepository.CreatePost(post);

            await _tagRepository.AddTags(createdPost.Id, hashtags);

            return createdPost;
        }

        public async Task<Post> TogglePostActiveStatus(int postId)
        {
            return await _postRepository.TogglePostActiveStatus(postId);
        }

        public async Task<IEnumerable<PostDTO>> GetPostsByUserId(int userId, bool activeStatus)
        {
            IEnumerable<Post> posts = await _postRepository.GetPostsByUserId(userId, activeStatus);

            List<PostDTO> postDtos = new List<PostDTO>();

            foreach (Post post in posts)
            {
                User user = await _userRepository.GetUserById(post.UserId);
                int likeCount = _likeRepository.GetLikeCountByPostId(post.Id);
                int commentCount = _commentRepository.GetCommentCountByPostId(post.Id);

                PostDTO postDto = new PostDTO
                {
                    Id = post.Id,
                    ImageUrl = post.ImageUrl,
                    Caption = post.Caption,
                    CreatedAt = post.CreatedAt ?? DateTime.MinValue,
                    Username = user.Username,
                    UserId = user.Id,
                    ProfilePicture = user.ProfilePicture,
                    LikeCount = likeCount,
                    CommentCount = commentCount,
                    IsLiked =  _likeRepository.IsPostLikedByUser(post.Id, userId),
                    FollowPostUser = _userRepository.IsFollowing(userId, user.Id).Result
                };

                postDtos.Add(postDto);
            }

            return postDtos;
        }

        public async Task<bool> UpdatePostCaption(int postId, string newCaption)
        {
            Post post = await _postRepository.GetPostById(postId);
            if (post == null)
            {
                return false;
            }

            post.Caption = newCaption;

            List<string> hashtags = ExtractHashtags(StringFunctions.CleanString_LowSymbol(newCaption));

            await _tagRepository.AddTags(postId,hashtags);

            
            await _postRepository.UpdatePost(post);
            return true;
        }

        public async Task<IEnumerable<PostDTO>> GetPostsForFollowings(int userId)
        {
            IEnumerable<int> followingUserIds = await _followRepository.GetFollowingUserIds(userId);
            IEnumerable<Post> posts = await _postRepository.GetPostsByUserIds(followingUserIds);

            List<PostDTO> postDtos = new List<PostDTO>();

            foreach (Post post in posts)
            {
                User user = await _userRepository.GetUserById(post.UserId);
                int likeCount = _likeRepository.GetLikeCountByPostId(post.Id);
                int commentCount = _commentRepository.GetCommentCountByPostId(post.Id);

                PostDTO postDto = new PostDTO
                {
                    Id = post.Id,
                    ImageUrl = post.ImageUrl,
                    Caption = post.Caption,
                    CreatedAt = post.CreatedAt ?? DateTime.MinValue,
                    Username = user.Username,
                    UserId = user.Id,
                    ProfilePicture = user.ProfilePicture,
                    LikeCount = likeCount,
                    CommentCount = commentCount,
                    IsLiked =  _likeRepository.IsPostLikedByUser(post.Id, userId),
                    FollowPostUser = _userRepository.IsFollowing(userId, user.Id).Result
                };

                postDtos.Add(postDto);
            }

            return postDtos;
        }

        public async Task<IEnumerable<PostDTO>> GetPostsByTagName(string tagName, int userId)
        {
            IEnumerable<Post> posts = await _postRepository.GetPostsByTagName(tagName.ToLower());

            List<PostDTO> postDtos = new List<PostDTO>();

            foreach (Post post in posts)
            {
                User user = await _userRepository.GetUserById(post.UserId);
                int likeCount = _likeRepository.GetLikeCountByPostId(post.Id);
                int commentCount = _commentRepository.GetCommentCountByPostId(post.Id);

                PostDTO postDto = new PostDTO
                {
                    Id = post.Id,
                    ImageUrl = post.ImageUrl,
                    Caption = post.Caption,
                    CreatedAt = post.CreatedAt ?? DateTime.MinValue,
                    Username = user.Username,
                    UserId = user.Id,
                    ProfilePicture = user.ProfilePicture,
                    LikeCount = likeCount,
                    CommentCount = commentCount,
                    IsLiked = _likeRepository.IsPostLikedByUser(post.Id, userId),
                    FollowPostUser = _userRepository.IsFollowing(userId, user.Id).Result
                };

                postDtos.Add(postDto);
            }
            return postDtos;
        }

        public async Task<PostDTO> GetPostById(int postId, int userId)
        {
            Post post = await _postRepository.GetPostById(postId);

            if (post == null)
            {
                return null;
            }

            User user = await _userRepository.GetUserById(post.UserId);
            int likeCount = _likeRepository.GetLikeCountByPostId(post.Id);
            int commentCount = _commentRepository.GetCommentCountByPostId(post.Id);

            PostDTO postDto = new PostDTO
            {
                Id = post.Id,
                ImageUrl = post.ImageUrl,
                Caption = post.Caption,
                CreatedAt = post.CreatedAt ?? DateTime.MinValue,
                Username = user.Username,
                UserId = user.Id,
                ProfilePicture = user.ProfilePicture,
                LikeCount = likeCount,
                CommentCount = commentCount,
                IsLiked =  _likeRepository.IsPostLikedByUser(post.Id, userId),
                FollowPostUser = _userRepository.IsFollowing(userId, user.Id).Result
            };

            return postDto;
        }

        public async Task<int> GetUserIdByPostId(int postId)
        {
            return await _postRepository.GetUserIdByPostId(postId);
        }

        public async Task<bool> DeletePost(int postId)
        {
            try
            {
                // Retrieve the post to ensure it exists and belongs to the user
                Post post = await _postRepository.GetPostById(postId);

                if (post == null)
                {
                    return false;
                }

                // Delete the post
                await _likeRepository.DeleteLikesByPostId(postId);
                await _commentRepository.DeleteCommentsByPostId(postId);
                await _tagRepository.DeleteTagBindingsByPostId(postId);
                await _postRepository.DeletePostById(postId);
                await _notificationRepository.DeleteNotificationsForPost(postId);

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while deleting the post.", ex);
            }
        }



    }
}
