﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using Snapspace_Services.Services.Utils;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;
using Snapspace_DataAccess.Utils;

namespace Snapspace_Services.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;
        private readonly ILogService _logger;

        public AuthService(IUserRepository userRepository, IConfiguration configuration, ILogService logger)
        {
            _userRepository = userRepository;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<(JwtTokenDTO, int)> Authenticate(LoginDTO request)
        {
            User user = await _userRepository.GetUserByUsername(request.Username.ToLower());

            if (user == null)
            {

                return (null, 404);
            }

            string hashedPassword = HashFunctions.HashString(request.Password);
            User validUser = await _userRepository.ValidateUser(request.Username.ToLower(), hashedPassword);
            if (validUser == null)
            {

                return (null, 401);
            }

            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            byte[] key = Encoding.ASCII.GetBytes(_configuration["JWTSecret"]);
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username)
            }),
                Expires = DateTime.Now.AddMinutes(5),
                Issuer = _configuration["JWTIssuer"],
                Audience = _configuration["JWTAudience"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            SecurityToken token = tokenHandler.CreateToken(tokenDescriptor);
            string handledToken = tokenHandler.WriteToken(token);

            await _userRepository.ActivateUser(request.Username.ToLower());

            

            await _userRepository.SetUserOnlineStatus(user.Id, true);

            await _logger.CreateLog(user.Id, "LOGIN", 0);

            return (new JwtTokenDTO
            {
                Token = handledToken,
                Expiration = token.ValidTo
            }, 0);
        }

        public async Task<(JwtTokenDTO, string)> Register(RegisterDTO request)
        {
            if (await _userRepository.UserExists(request.Username.ToLower(), request.Email))
            {
                return (null, "Username or email already exists");
            }

            User user = new User
            {
                Username = request.Username.ToLower(),
                Password = HashFunctions.HashString(request.Password),
                Email = request.Email,
                FullName = request.FullName,
                SecurityQuestionId = request.SecurityQuestionId,
                SecurityAnswer = request.SecurityAnswer,
                CreatedAt = DateTime.Now,
                OnlineStatus = false,
                ProfilePicture = null,
                Bio = null
            };

            await _userRepository.CreateUser(user);

            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            byte[] key = Encoding.ASCII.GetBytes(_configuration["JWTSecret"]);
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username)
            }),
                Expires = DateTime.Now.AddDays(7),
                Issuer = _configuration["JWTIssuer"],
                Audience = _configuration["JWTAudience"],
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            int userId = await _userRepository.GetUserIdByUsername(request.Username.ToLower());
            await _logger.CreateLog(userId, "REGISTER", 0);

            SecurityToken token = tokenHandler.CreateToken(tokenDescriptor);
            return (new JwtTokenDTO
            {
                Token = tokenHandler.WriteToken(token),
                Expiration = token.ValidTo
            }, null);
        }

        public async Task<bool> Logout(int userId)
        {
            try
            {
                await _userRepository.SetUserOnlineStatus(userId, false);
                await _logger.CreateLog(userId, "LOGOUT", 0);
                return true;
            }
            catch
            {
                return false;
            }
            
        }

        public async Task<(bool, int, string)> VerifySecurityAnswer(string username, string answer)
        {
            User user = await _userRepository.GetUserByUsername(username);
            if (user == null)
            {
                return (false, 0, "");
            }

            bool answerVerificationResult = StringFunctions.CleanString_LowSpaceSymbol(user.SecurityAnswer) == StringFunctions.CleanString_LowSpaceSymbol(answer);
            int userId = await _userRepository.GetUserIdByUsername(username.ToLower());

            if (answerVerificationResult)
            {
                await _logger.CreateLog(userId, "SECURITY ANSWER MATCHED", 0);
            }
            else
            {
                await _logger.CreateLog(userId, "SECURITY ANSWER NOT MATCHED", 0);
            }

            return (answerVerificationResult, userId, user.Password);
        }


    }
}
