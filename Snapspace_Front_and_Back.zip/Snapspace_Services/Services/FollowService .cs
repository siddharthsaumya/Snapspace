﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class FollowService : IFollowService
    {
        private readonly IFollowRepository _followRepository;

        public FollowService(IFollowRepository followRepository)
        {
            _followRepository = followRepository ?? throw new ArgumentNullException(nameof(followRepository));
        }

        public async Task<bool> UnfollowUser(int userId, int unfollowUserId)
        {
            return await _followRepository.UnfollowUser(userId, unfollowUserId);
        }

        public async Task<IEnumerable<UserSearchDTO>> GetFollowingUsers(int userId)
        {
            IEnumerable<User> users = await _followRepository.GetFollowingUsers(userId);

            return users.Select(u => new UserSearchDTO
            {
                Id = u.Id,
                FullName = u.FullName,
                ProfilePicture = u.ProfilePicture,
                Username = u.Username
            }).ToList();
        }

        public async Task<IEnumerable<UserSearchDTO>> GetFollowerUsers(int userId)
        {
            IEnumerable<User> users = await _followRepository.GetFollowerUsers(userId);

            return users.Select(u => new UserSearchDTO
            {
                Id = u.Id,
                FullName = u.FullName,
                ProfilePicture = u.ProfilePicture,
                Username = u.Username
            }).ToList();

        }

        public bool IsFollowing(int userId, int targetUserId)
        {
            return _followRepository.IsFollowing(userId, targetUserId);
        }

    }
}
