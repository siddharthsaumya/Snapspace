﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class ChatService : IChatService
    {
        private readonly IChatRepository _chatRepository;
        private readonly IMessageRepository _messageRepository;
        private readonly IUserRepository _userRepository;

        public ChatService(IChatRepository chatRepository, IMessageRepository messageRepository, IUserRepository userRepository)
        {
            _chatRepository = chatRepository;
            _messageRepository = messageRepository;
            _userRepository = userRepository;
        }

        public async Task<Message> SendMessage(MessageDTO messageDto)
        {
            User sender = await _userRepository.GetUserById(messageDto.SenderId);
            User recipient = await _userRepository.GetUserById(messageDto.RecipientId);

            if (sender == null || recipient == null)
            {
                throw new ArgumentException("Invalid sender or recipient.");
            }

            Chat chat = await _chatRepository.GetChatByParticipants(messageDto.SenderId, messageDto.RecipientId);
            if (chat == null)
            {
                chat = new Chat
                {
                    CreatedAt = DateTime.Now,
                    Users = new List<User> { sender, recipient }
                };
                chat = await _chatRepository.CreateChat(chat);
            }

            Message message = new Message
            {
                ChatId = chat.Id,
                SenderId = messageDto.SenderId,
                MessageText = messageDto.MessageText,
                CreatedAt = DateTime.Now,
                ReadStatus = false
            };

            return await _messageRepository.AddMessage(message);
        }

        public async Task DeleteMessage(int messageId)
        {
            Message message = await _messageRepository.GetMessageById(messageId);

            if (message == null)
            {
                throw new KeyNotFoundException("Message not found.");
            }

            await _messageRepository.DeleteMessage(message);
        }

        public async Task DeleteChat(int chatId)
        {
            Chat chat = await _chatRepository.GetChatById(chatId);

            if (chat == null)
            {
                throw new KeyNotFoundException("Chat not found.");
            }

            IEnumerable<Message> messages = await _messageRepository.GetMessagesByChatId(chatId);

            await _chatRepository.RemoveChatParticipants(chat);

            await _messageRepository.DeleteMessages(messages);

            await _chatRepository.DeleteChat(chat);
        }

        public async Task<IEnumerable<ChatDTO>> GetChatsWithUnreadMessageCount(int userId)
        {
            IEnumerable<Chat> chats = await _chatRepository.GetChatsByUserId(userId);

            IEnumerable<ChatDTO> chatDTOs = chats.Select(c =>
            {
                Message latestMessage = c.Messages
                    .OrderByDescending(m => m.CreatedAt)
                    .FirstOrDefault();

                return new ChatDTO
                {
                    ChatId = c.Id,
                    CreatedAt = c.CreatedAt,
                    Participants = c.Users.Select(u => new ChatUserDTO
                    {
                        Id = u.Id,
                        Username = u.Username,
                        ProfilePicture = u.ProfilePicture
                    }).ToList(),
                    UnreadMessageCount = c.Messages.Count(m => m.ReadStatus == false && m.SenderId != userId),
                    LatestMessage = latestMessage != null ?  latestMessage.MessageText : null,
                    LatestMessageTime = latestMessage != null ? latestMessage.CreatedAt : null
                };
            });

            return chatDTOs;
        }


        public async Task<IEnumerable<ChatMessageDTO>> GetChatMessages(int UserId, int chatId)
        {
            IEnumerable<Message> messages = await _messageRepository.GetMessagesByChatId(chatId);

            List<ChatMessageDTO> messageDTOs = messages.Select(m => new ChatMessageDTO
            {
                Id = m.Id,
                ChatId = m.ChatId,
                SenderId = m.SenderId,
                MessageText = m.MessageText,
                CreatedAt = m.CreatedAt,
                ReadStatus = m.ReadStatus
            }).ToList();

            await _messageRepository.UpdateMessagesReadStatus(UserId, chatId);

            return messageDTOs;
        }

        public async Task<ChatDetailsDTO> GetChatDetails(int userId, int targetUserId)
        {
            var chat = await _chatRepository.GetChatWithUserDetails(userId, targetUserId);

            if (chat != null)
            {
                var userProfilePicture = chat.Users.FirstOrDefault(u => u.Id == targetUserId)?.ProfilePicture;
                var username = chat.Users.FirstOrDefault(u => u.Id == targetUserId)?.Username;

                return new ChatDetailsDTO
                {
                    ChatId = chat.Id,
                    UserProfilePicture = userProfilePicture,
                    Username = username
                };
            }
            else
            {
                User user = await _userRepository.GetUserById(targetUserId);
                String userProfilePicture = user.ProfilePicture;
                String username = user.Username;

                return new ChatDetailsDTO
                {
                    ChatId = null,
                    UserProfilePicture = userProfilePicture,
                    Username = username
                };
            }
        }



    }

}
