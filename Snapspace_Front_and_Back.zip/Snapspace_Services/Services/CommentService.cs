﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class CommentService : ICommentService
    {
        private readonly ICommentRepository _commentRepository;
        private readonly INotificationRepository _notificationRepository;

        public CommentService(ICommentRepository commentRepository, INotificationRepository notificationRepository)
        {
            _commentRepository = commentRepository;
            _notificationRepository = notificationRepository;
        }

        public async Task AddComment(int postId, int userId, string commentText)
        {
            Comment comment = new Comment
            {
                PostId = postId,
                UserId = userId,
                CommentText = commentText,
                ParentCommentId = null,
                CreatedAt = DateTime.Now,
            };

            await _notificationRepository.AddNotification(userId, 4, postId);

            await _commentRepository.AddComment(comment);
        }

        public async Task AddReply(int postId, int userId, string commentText, int parentCommentId)
        {
            Comment reply = new Comment
            {
                PostId = postId,
                UserId = userId,
                CommentText = commentText,
                ParentCommentId = parentCommentId,
                CreatedAt = DateTime.Now
            };

            await _notificationRepository.AddNotification(userId, 4, postId);

            await _commentRepository.AddComment(reply);
        }

        public async Task DeleteComment(int commentId)
        {
            Comment comment = await _commentRepository.GetCommentById(commentId);

            if (comment == null)
            {
                throw new KeyNotFoundException("Comment not found.");
            }

            if (comment.ParentCommentId == null)
            {
                IEnumerable<Comment> replies = await _commentRepository.GetRepliesByParentId(commentId);
                foreach (Comment reply in replies)
                {
                    await _commentRepository.DeleteComment(reply);
                }
            }

            await _commentRepository.DeleteComment(comment);
        }

        public async Task EditComment(int commentId, string newCommentText)
        {
            Comment comment = await _commentRepository.GetCommentById(commentId);

            if (comment == null)
            {
                throw new KeyNotFoundException("Comment not found.");
            }

            comment.CommentText = newCommentText;

            await _commentRepository.UpdateComment(comment);
        }

        public async Task<IEnumerable<CommentDTO>> GetCommentsByPostId(int postId)
        {
            IEnumerable<Comment> comments = await _commentRepository.GetCommentsByPostId(postId);

            List<CommentDTO> commentDtos = comments.Select(c => new CommentDTO
            {
                Id = c.Id,
                User = new ChatUserDTO
                {
                    Id = c.User.Id,
                    Username = c.User.Username,
                    ProfilePicture = c.User.ProfilePicture
                },
                CommentText = c.CommentText,
                CreatedAt = c.CreatedAt,
                Replies = c.InverseParentComment.Select(r => new CommentDTO
                {
                    Id = r.Id,
                    User = new ChatUserDTO
                    {
                        Id = r.User.Id,
                        Username = r.User.Username,
                        ProfilePicture = r.User.ProfilePicture
                    },
                    CommentText = r.CommentText,
                    CreatedAt = r.CreatedAt
                }).ToList()
            }).ToList();

            return commentDtos;
        }
    }

}
