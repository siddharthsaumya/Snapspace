﻿using Microsoft.Extensions.Hosting;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_DataAccess.Utils;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IPostRepository _postRepository;
        private readonly ILikeRepository _likeRepository;
        private readonly IFollowRepository _followRepository;
        private readonly IFollowRequestRepository _followRequestRepository;

        public UserService(IUserRepository userRepository, IPostRepository postRepository, ILikeRepository likeRepository, IFollowRepository followRepository, IFollowRequestRepository followRequestRepository)
        {
            _userRepository = userRepository;
            _postRepository = postRepository;
            _likeRepository = likeRepository;
            _followRepository = followRepository;
            _followRequestRepository = followRequestRepository;
        }

        public async Task<IEnumerable<UserDTO>> GetAllUsers()
        {
            IEnumerable<User> users = await _userRepository.GetAllUsers();
            return users.Select(user => new UserDTO
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email,
                FullName = user.FullName,
                Bio = user.Bio,
                ProfilePicture = user.ProfilePicture,
                CreatedAt = user.CreatedAt,
                OnlineStatus = user.OnlineStatus,
                Active = user.Active
            });
        }

        public async Task<UserByIdDTO> GetUserById(int userId, int currentUserId)
        {
            User user = await _userRepository.GetUserById(userId);

            if (user == null)
                throw new KeyNotFoundException("User not found.");

            int followerCount = await _userRepository.GetFollowerCount(userId);
            int followingCount = await _userRepository.GetFollowingCount(userId);
            int postCount = await _userRepository.GetPostCount(userId);
            bool isFollowing = await _userRepository.IsFollowing(currentUserId, userId);

            IEnumerable<Post> posts = isFollowing ? await _postRepository.GetPostsByUserId(userId, true) : new List<Post>();

            IEnumerable<Task<PostDTO>> postDtoTasks = posts.Select(async p => new PostDTO
            {
                Id = p.Id,
                ImageUrl = p.ImageUrl,
                Caption = p.Caption,
                CreatedAt = p.CreatedAt ?? DateTime.MinValue,
                Username = p.User.Username,
                ProfilePicture = p.User.ProfilePicture,
                LikeCount = p.Likes.Count(),
                CommentCount = p.Comments.Count(),
                IsLiked =  _likeRepository.IsPostLikedByUser(p.Id, currentUserId)
            });

            PostDTO[] postDtos = await Task.WhenAll(postDtoTasks);

            UserByIdDTO userDto = new UserByIdDTO
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email,
                FullName = user.FullName,
                Bio = user.Bio,
                ProfilePicture = user.ProfilePicture,
                CreatedAt = user.CreatedAt,
                OnlineStatus = user.OnlineStatus,
                Active = user.Active,
                FollowerCount = followerCount,
                FollowingCount = followingCount,
                PostCount = postCount,
                FollowStatus = isFollowing,
                Posts = postDtos.ToList(),
                OwnAccount = (userId == currentUserId),
                ProfileType = _followRequestRepository.HasPendingFollowRequest(userId, currentUserId)
    ? "REQ-SENT"
    : (_followRepository.IsFollowing(userId, currentUserId)
        ? "FOLLOW"
        : "NOT-FOLLOW")

            };

            return userDto;
        }

        public async Task<UserByIdDTO> GetUserInfo(int Id)
        {
            User user = await _userRepository.GetUserById(Id);

            if (user == null)
                throw new KeyNotFoundException("User not found.");

            int followerCount = await _userRepository.GetFollowerCount(Id);
            int followingCount = await _userRepository.GetFollowingCount(Id);
            int postCount = await _userRepository.GetPostCount(Id);
            bool isFollowing = true;

            IEnumerable<Post> posts = isFollowing ? await _postRepository.GetPostsByUserId(Id, true) : new List<Post>();

            UserByIdDTO userDto = new UserByIdDTO();

            if (posts.Count() > 0) {
                IEnumerable<Task<PostDTO>> postDtoTasks = posts.Select(async p => new PostDTO
                {
                    Id = p.Id,
                    ImageUrl = p.ImageUrl,
                    Caption = p.Caption,
                    CreatedAt = p.CreatedAt ?? DateTime.MinValue,
                    Username = p.User.Username,
                    ProfilePicture = p.User.ProfilePicture,
                    LikeCount = p.Likes.Count(),
                    CommentCount = p.Comments.Count(),
                    IsLiked = _likeRepository.IsPostLikedByUser(p.Id, Id)
                });

                PostDTO[] postDtos = await Task.WhenAll(postDtoTasks);

                userDto = new UserByIdDTO
                {
                    Id = user.Id,
                    Username = user.Username,
                    Email = user.Email,
                    FullName = user.FullName,
                    Bio = user.Bio,
                    ProfilePicture = user.ProfilePicture,
                    CreatedAt = user.CreatedAt,
                    OnlineStatus = user.OnlineStatus,
                    Active = user.Active,
                    FollowerCount = followerCount,
                    FollowingCount = followingCount,
                    PostCount = postCount,
                    FollowStatus = isFollowing,
                    Posts = postDtos.ToList(),
                    OwnAccount = true
                };
            }
            else
            {
                userDto = new UserByIdDTO
                {
                    Id = user.Id,
                    Username = user.Username,
                    Email = user.Email,
                    FullName = user.FullName,
                    Bio = user.Bio,
                    ProfilePicture = user.ProfilePicture,
                    CreatedAt = user.CreatedAt,
                    OnlineStatus = user.OnlineStatus,
                    Active = user.Active,
                    FollowerCount = followerCount,
                    FollowingCount = followingCount,
                    PostCount = postCount,
                    FollowStatus = isFollowing,
                    Posts = new List<PostDTO>()
                };
            }
            
            

            return userDto;
        }


        public async Task<bool> UsernameExists(string username)
        {
            return await _userRepository.UsernameExists(username.ToLower());
        }

        public async Task<bool> DeleteUser(int id, string password)
        {
            return await _userRepository.DeleteUser(id, password);
        }

        public async Task<int> UpdatePassword(int userId, string currentPassword, string newPassword)
        {
            User user = await _userRepository.GetUserById(userId);
            if (user == null)
            {
                return 404;
            }
            if (user.Password == HashFunctions.HashString(currentPassword) || user.Password == currentPassword)
            {
                
                bool function = await _userRepository.UpdatePassword(userId, newPassword);
                if (function == true) return 200;
                else return 500;
            }
            else
            {
                return 400;
            }
            
        }

        public async Task<bool> DeactivateUser(int userId, string password)
        {
            return await _userRepository.DeactivateUser(userId, password);
        }

        public async Task<bool> ToggleUserOnlineStatus(int userId)
        {
            Nullable<bool> currentStatus = await _userRepository.GetUserOnlineStatus(userId);

            if (currentStatus == null)
            {
                return false;
            }

            bool newStatus = !currentStatus.Value;
            await _userRepository.SetUserOnlineStatus(userId, newStatus);
            return true;
        }

        public async Task<bool> UpdateUser(int userId, UpdateUserDTO updateUserDTO)
        {
            return await _userRepository.UpdateUser(
                userId,
                updateUserDTO.Username,
                updateUserDTO.Email,
                updateUserDTO.FullName,
                updateUserDTO.Bio,
                updateUserDTO.ProfilePicture
            );
        }

        public async Task<IEnumerable<UserSearchDTO>> SearchUsers(string searchTerm)
        {
            IEnumerable<User> users = await _userRepository.SearchUsers(searchTerm.ToLower());

            return users.Select(u => new UserSearchDTO
            {
                Id = u.Id,
                FullName = u.FullName,
                ProfilePicture = u.ProfilePicture,
                Username = u.Username
            }).ToList();
        }

        public async Task<bool?> GetUserOnlineStatus(int userId)
        {
            return await _userRepository.GetUserOnlineStatus(userId);
        }

        public async Task<string?> GetSecurityQuestionByUsername(string username)
        {
            return await _userRepository.GetSecurityQuestionByUsername(username);
        }

        public async Task<int> GetUserIdByUsername(string username)
        {
            return await _userRepository.GetUserIdByUsername(username.ToLower());
        }

    }
}
