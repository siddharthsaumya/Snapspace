﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class LikeService : ILikeService
    {
        private readonly ILikeRepository _likeRepository;
        private readonly INotificationRepository _notificationRepository;

        public LikeService(ILikeRepository likeRepository, INotificationRepository notificationRepository)
        {
            _likeRepository = likeRepository;
            _notificationRepository = notificationRepository;
        }

        public async Task<bool> ToggleLike(int postId, int userId)
        {
            bool isLiked = _likeRepository.IsPostLikedByUser(postId, userId);

            if (isLiked)
            {
                await _likeRepository.RemoveLike(postId, userId);
                return true;
            }
            else
            {
                Like like = new Like
                {
                    PostId = postId,
                    UserId = userId,
                    CreatedAt = DateTime.Now
                };
                await _likeRepository.AddLike(like);
                await _notificationRepository.AddNotification(userId, 3, postId);
                return true;
            }
            return false;
        }
    }

}
