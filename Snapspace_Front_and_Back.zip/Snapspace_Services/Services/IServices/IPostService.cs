﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IPostService
    {
        Task<Post> CreatePost(NewPostDTO newPostDTO);
        Task<Post> TogglePostActiveStatus(int postId);
        Task<IEnumerable<PostDTO>> GetPostsByUserId(int userId, bool activeStatus);
        Task<bool> UpdatePostCaption(int postId, string newCaption);
        Task<IEnumerable<PostDTO>> GetPostsForFollowings(int userId);
        Task<IEnumerable<PostDTO>> GetPostsByTagName(string tagName, int userId);
        Task<PostDTO> GetPostById(int postId, int userId);
        Task<int> GetUserIdByPostId(int postId);
        Task<bool> DeletePost(int postId);
    }

}
