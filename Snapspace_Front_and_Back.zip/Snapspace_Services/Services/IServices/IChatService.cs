﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IChatService
    {
        Task<Message> SendMessage(MessageDTO messageDto);
        Task DeleteMessage(int messageId);
        Task DeleteChat(int chatId);
        Task<IEnumerable<ChatDTO>> GetChatsWithUnreadMessageCount(int userId);
        Task<IEnumerable<ChatMessageDTO>> GetChatMessages(int UserId, int chatId);
        Task<ChatDetailsDTO> GetChatDetails(int userId, int targetUserId);
    }

}
