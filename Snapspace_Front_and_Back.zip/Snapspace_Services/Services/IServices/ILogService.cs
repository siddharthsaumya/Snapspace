﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface ILogService
    {
        Task CreateLog(int userId, string logDetails, int logType);
        Task<IEnumerable<LogDTO>> GetLogsByUserId(int userId);
    }
}
