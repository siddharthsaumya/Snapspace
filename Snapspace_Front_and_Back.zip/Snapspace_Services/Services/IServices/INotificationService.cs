﻿using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface INotificationService
    {
        Task<IEnumerable<NotificationDTO>> GetNotificationsByUserId(int userId);
        Task<int> GetUnreadNotificationCountByUserId(int userId);
    }
}
