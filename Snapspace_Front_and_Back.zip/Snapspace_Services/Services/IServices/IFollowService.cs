﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IFollowService
    {
        Task<bool> UnfollowUser(int userId, int unfollowUserId);
        Task<IEnumerable<UserSearchDTO>> GetFollowingUsers(int userId);
        Task<IEnumerable<UserSearchDTO>> GetFollowerUsers(int userId);
        bool IsFollowing(int userId, int targetUserId);
    }

}
