﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface ILikeService
    {
        Task<bool> ToggleLike(int postId, int userId);
    }
}
