﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IUserService
    {
        Task<IEnumerable<UserDTO>> GetAllUsers();
        Task<UserByIdDTO> GetUserById(int TargetUserId, int Id);
        Task<UserByIdDTO> GetUserInfo(int Id);
        Task<bool> UsernameExists(string username);
        Task<bool> DeleteUser(int id, string password);

        Task<int> UpdatePassword(int userId, string currentPassword, string newPassword);
        Task<bool> DeactivateUser(int userId, string password);
        Task<bool> ToggleUserOnlineStatus(int userId);
        Task<bool> UpdateUser(int userId, UpdateUserDTO updateUserDTO);
        Task<IEnumerable<UserSearchDTO>> SearchUsers(string searchTerm);
        Task<bool?> GetUserOnlineStatus(int userId);
        Task<string?> GetSecurityQuestionByUsername(string username);
        Task<int> GetUserIdByUsername(string username);
    }
}
