﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IFollowRequestService
    {
        Task<IEnumerable<FollowRequestDTO>> GetPendingFollowRequests(int userId);
        Task<IEnumerable<FollowRequestDTO>> GetFollowRequestsSentByUser(int userId);
        Task<bool> DeleteFollowRequest(int userId, int removeFollowRequestId);
        Task<bool> CreateFollowRequest(NewFollowRequestDTO followRequestDTO);
        Task<bool> RejectFollowRequest(int followRequestId);
        Task<bool> AcceptFollowRequest(int followRequestId);
    }

}
