﻿using Snapspace_DataAccess.Models;
using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface IAuthService
    {
        Task<(JwtTokenDTO, int)> Authenticate(LoginDTO request);
        Task<(JwtTokenDTO, string)> Register(RegisterDTO request);
        Task<(bool, int, string)> VerifySecurityAnswer(string username, string answer);
        Task<bool> Logout(int UserId);
    }
}
