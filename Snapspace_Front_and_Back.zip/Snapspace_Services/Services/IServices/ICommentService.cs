﻿using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface ICommentService
    {
        Task AddComment(int postId, int userId, string commentText);
        Task AddReply(int postId, int userId, string commentText, int parentCommentId);
        Task DeleteComment(int commentId);
        Task EditComment(int commentId, string newCommentText);
        Task<IEnumerable<CommentDTO>> GetCommentsByPostId(int postId);
    }
}
