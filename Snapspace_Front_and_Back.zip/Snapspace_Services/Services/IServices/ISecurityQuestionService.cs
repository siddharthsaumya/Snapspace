﻿using Snapspace_Services.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services.IServices
{
    public interface ISecurityQuestionService
    {
        Task<List<SecurityQuestionDTO>> GetSecurityQuestions();
        Task<bool> CreateSecurityQuestion(CreateSecurityQuestionDTO questionDto);
        Task<(string Question, string Answer)?> GetSecurityQuestionAndAnswer(int userId);
        Task<bool> UpdateSecurityQuestionAndAnswer(int userId, UpdateSecurityQuestionDTO updateSecurityQuestionDTO);
    }
}
