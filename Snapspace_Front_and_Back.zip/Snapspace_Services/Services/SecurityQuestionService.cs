﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class SecurityQuestionService : ISecurityQuestionService
    {
        private readonly ISecurityQuestionRepository _securityQuestionRepository;
        private readonly ILogService _logger;

        public SecurityQuestionService(ISecurityQuestionRepository securityQuestionRepository, ILogService logger)
        {
            _securityQuestionRepository = securityQuestionRepository;
            _logger = logger;
        }

        public async Task<List<SecurityQuestionDTO>> GetSecurityQuestions()
        {
            List<SecurityQuestion> questions = await _securityQuestionRepository.GetSecurityQuestions();
            return questions.Select(q => new SecurityQuestionDTO { Id = q.Id, Question = q.Question }).ToList();
        }

        public async Task<bool> CreateSecurityQuestion(CreateSecurityQuestionDTO questionDto)
        {
            SecurityQuestion question = new SecurityQuestion { Question = questionDto.Question };
            return await _securityQuestionRepository.CreateSecurityQuestion(question);
        }

        public async Task<(string Question, string Answer)?> GetSecurityQuestionAndAnswer(int userId)
        {
            return await _securityQuestionRepository.GetSecurityQuestionAndAnswer(userId);
        }

        public async Task<bool> UpdateSecurityQuestionAndAnswer(int userId, UpdateSecurityQuestionDTO updateSecurityQuestionDTO)
        {
            return await _securityQuestionRepository.UpdateSecurityQuestionAndAnswer(
                userId,
                updateSecurityQuestionDTO.SecurityQuestionId,
                updateSecurityQuestionDTO.SecurityAnswer
            );
        }
    }
}
