﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _notificationRepository;
        private readonly IUserRepository _userRepository;
        private readonly IPostRepository _postRepository;
        private readonly IUserService _userService;
        private readonly IPostService _postService;

        public NotificationService(INotificationRepository notificationRepository, IUserRepository userRepository,IPostRepository postRepository, IUserService userService, IPostService postService)
        {
            _notificationRepository = notificationRepository;
            _userRepository = userRepository;
            _postRepository = postRepository;
            _userService = userService;
            _postService = postService;
        }

        public async Task<IEnumerable<NotificationDTO>> GetNotificationsByUserId(int userId)
        {
            IEnumerable< Notification> notifications = await _notificationRepository.GetNotificationsByUserId(userId);

            List< NotificationDTO> notificationDTOs = new List<NotificationDTO>();

            foreach (Notification notification in notifications)
            {
                UserByIdDTO user = null;
                PostDTO post = null;
                NotificationDTO notificationDTO = new NotificationDTO();

                if (notification.NotificationType == 0 || notification.NotificationType == 1 || notification.NotificationType == 2)
                {
                    user = await _userService.GetUserById(notification.SourceId, userId);
                    notificationDTO = new NotificationDTO
                    {
                        Id = notification.Id,
                        UserId = notification.UserId,
                        NotificationType = notification.NotificationType,
                        SourceId = notification.SourceId,
                        CreatedAt = notification.CreatedAt,
                        ReadStatus = notification.ReadStatus,
                        User = new ChatUserDTO
                        {

                            Username = user.Username,
                            ProfilePicture =user.ProfilePicture
                        }
                    };
                }
                else if (notification.NotificationType == 3 || notification.NotificationType == 4)
                {
                    post = await _postService.GetPostById(notification.SourceId, userId);
                    notificationDTO  = new NotificationDTO
                    {
                        Id = notification.Id,
                        UserId = notification.UserId,
                        NotificationType = notification.NotificationType,
                        SourceId = notification.SourceId,
                        CreatedAt = notification.CreatedAt,
                        ReadStatus = notification.ReadStatus,
                        User = new ChatUserDTO
                        {
                            Username = post.Username,
                            ProfilePicture = post.ProfilePicture
                        }
                    };
                }

                await _notificationRepository.MarkNotificationAsRead(notification.Id);

                notificationDTOs.Add(notificationDTO);
            }

            return notificationDTOs;
        }

        public async Task<int> GetUnreadNotificationCountByUserId(int userId)
        {
            return await _notificationRepository.GetUnreadNotificationCountByUserId(userId);
        }


    }
}
