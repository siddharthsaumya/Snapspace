﻿using Microsoft.Extensions.Logging;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class FollowRequestService : IFollowRequestService
    {
        private readonly IFollowRequestRepository _followRequestRepository;
        private readonly IUserRepository _userRepository;
        private readonly INotificationRepository _notificationRepository;
        private readonly ILogService _logger;

        public FollowRequestService(INotificationRepository notificationRepository,IUserRepository userRepository,IFollowRequestRepository followRequestRepository, ILogService logger)
        {
            _followRequestRepository = followRequestRepository;
            _userRepository = userRepository;
            _notificationRepository = notificationRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<FollowRequestDTO>> GetPendingFollowRequests(int userId)
        {
            IEnumerable<FollowRequest> followRequests = await _followRequestRepository.GetPendingFollowRequests(userId);

            List<FollowRequestDTO> followRequestDTOs = followRequests.Select(fr => new FollowRequestDTO
            {
                Id = fr.Id,
                UserId = fr.FromUser.Id,
                ProfilePicture = fr.FromUser.ProfilePicture,
                FullName = fr.FromUser.FullName,
                Username = fr.FromUser.Username
            }).ToList();

            return followRequestDTOs;
        }

        public async Task<IEnumerable<FollowRequestDTO>> GetFollowRequestsSentByUser(int userId)
        {
            IEnumerable<FollowRequest> followRequests = await _followRequestRepository.GetFollowRequestsSentByUser(userId);

            List<FollowRequestDTO> followRequestDTOs = followRequests.Select(fr => new FollowRequestDTO
            {
                Id = fr.Id,
                UserId = fr.ToUser.Id,
                ProfilePicture = fr.ToUser.ProfilePicture,
                FullName = fr.ToUser.FullName,
                Username = fr.ToUser.Username,
                CreatedAt = fr.CreatedAt
            }).ToList();

            return followRequestDTOs;
        }

        public async Task<bool> DeleteFollowRequest(int userId, int removeFollowRequestId)
        {
            return await _followRequestRepository.DeleteFollowRequest(userId, removeFollowRequestId);
        }

        public async Task<bool> CreateFollowRequest(NewFollowRequestDTO followRequestDTO)
        {
            FollowRequest followRequest = new FollowRequest
            {
                FromUserId = followRequestDTO.UserId,
                ToUserId = followRequestDTO.FollowUserId,
                Status = 0,
                CreatedAt = DateTime.Now
            };

            await _notificationRepository.AddNotification(followRequestDTO.FollowUserId, 0, followRequestDTO.UserId);

            return await _followRequestRepository.CreateFollowRequest(followRequest);
        }

        public async Task<bool> RejectFollowRequest(int followRequestId)
        {
            return await _followRequestRepository.RejectFollowRequest(followRequestId);
        }

        public async Task<bool> AcceptFollowRequest(int followRequestId)
        {

            FollowRequest followRequest = await _followRequestRepository.GetFollowRequestById(followRequestId);
            await _notificationRepository.AddNotification(followRequest.FromUserId, 2, followRequest.ToUserId);
            await _notificationRepository.AddNotification(followRequest.ToUserId, 1, followRequest.FromUserId);

            return await _followRequestRepository.AcceptFollowRequest(followRequestId);
        }


    }

}
