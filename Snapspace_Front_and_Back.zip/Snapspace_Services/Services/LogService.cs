﻿using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_Services.DTOs;
using Snapspace_Services.Services.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.Services
{
    public class LogService : ILogService
    {
        private readonly ILogRepository _logRepository;

        public LogService(ILogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task CreateLog(int userId, string logDetails, int logType)
        {
            Log log = new Log
            {
                LogDetails = logDetails,
                LogType = logType
            };

            await _logRepository.CreateLog(userId, log);
        }
        public async Task<IEnumerable<LogDTO>> GetLogsByUserId(int userId)
        {
            IEnumerable<Log> logs = await _logRepository.GetLogsByUserId(userId);
            return logs.Select(log => new LogDTO
            {
                Id = log.Id,
                LogType = log.LogType,
                LogDetails = log.LogDetails,
                CreatedAt = log.CreatedAt,
                UserId = log.UserId
            });
        }
    }
}
