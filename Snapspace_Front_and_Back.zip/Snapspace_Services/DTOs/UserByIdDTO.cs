﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class UserByIdDTO
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; }

        [Required]
        [StringLength(100)]
        [EmailAddress]
        public string Email { get; set; }

        [StringLength(100)]
        public string? FullName { get; set; }

        public string? Bio { get; set; }

        public string? ProfilePicture { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? CreatedAt { get; set; }

        [Required]
        public bool? OnlineStatus { get; set; }

        [Required]
        public bool? Active { get; set; }

        public int FollowerCount { get; set; }

        public int FollowingCount { get; set; }

        public int PostCount { get; set; }

        public bool FollowStatus { get; set; }

        public List<PostDTO> Posts { get; set; } = new List<PostDTO>();
        public bool OwnAccount { get; set; }
        public string ProfileType { get; set; }
    }
}
