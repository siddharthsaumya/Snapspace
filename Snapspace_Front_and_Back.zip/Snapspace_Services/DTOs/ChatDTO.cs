﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class ChatDTO
    {
        public int ChatId { get; set; }
        public DateTime? CreatedAt { get; set; }
        public List<ChatUserDTO> Participants { get; set; }
        public int UnreadMessageCount { get; set; }
        public string? LatestMessage { get; set; }
        public DateTime? LatestMessageTime { get; set; }
    }

}
