﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class VerifySecurityAnswerDTO
    {
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9._]+$", ErrorMessage = "Username can only contain alphabets, numbers, and the special symbols . and _")]
        public string Username { get; set; }

        [Required]
        public string Answer { get; set; }
    }
}
