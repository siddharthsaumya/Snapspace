﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class LogDTO
    {
        public int Id { get; set; }
        public int? LogType { get; set; }
        public int? UserId { get; set; }
        public string? LogDetails { get; set; }
        public DateTime? CreatedAt { get; set; }
    }
}
