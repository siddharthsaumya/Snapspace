﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class CommentDTO
    {
        public int Id { get; set; }
        public ChatUserDTO User { get; set; }
        public string CommentText { get; set; }
        public DateTime? CreatedAt { get; set; }
        public List<CommentDTO> Replies { get; set; }
    }

}
