﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class UpdateSecurityQuestionDTO
    {
        [Required]
        public int SecurityQuestionId { get; set; }

        [Required]
        public string SecurityAnswer { get; set; }
    }
}
