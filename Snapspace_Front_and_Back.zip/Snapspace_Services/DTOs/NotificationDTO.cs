﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class NotificationDTO
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public int NotificationType { get; set; }
        public int? SourceId { get; set; }
        public DateTime? CreatedAt { get; set; }
        public bool? ReadStatus { get; set; }
        public ChatUserDTO User { get; set; }

    }
}
