﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class AddCommentDTO
    {
        [Required]
        public int PostId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        [StringLength(500)]
        public string CommentText { get; set; }

        public int? ParentCommentId { get; set; }
    }
}
