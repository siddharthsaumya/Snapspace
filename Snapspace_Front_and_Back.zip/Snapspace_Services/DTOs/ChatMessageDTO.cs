﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class ChatMessageDTO
    {
        public int Id { get; set; }
        public int? ChatId { get; set; }
        public int? SenderId { get; set; }
        public string? MessageText { get; set; }
        public DateTime? CreatedAt { get; set; }
        public bool? ReadStatus { get; set; }
    }
}
