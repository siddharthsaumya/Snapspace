﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_Services.DTOs
{
    public class ChatDetailsDTO
    {
        public int? ChatId { get; set; }
        public string UserProfilePicture { get; set; }
        public string Username { get; set; }
    }
}
