import React, { useState } from 'react';
import { Outlet, Link } from 'react-router-dom';
import SearchBar from '../Components/SearchBar/SearchBar';
import './Nav.css';

import Home_Img from '../Assets/home.png';
import Chat_Img from '../Assets/chat.png';
import Create_Img from '../Assets/create.png';
import Notification_Img from '../Assets/notification.png';
import Profile_Img from '../Assets/profile.png';

import Home_Img_S from '../Assets/home_selected.png';
import Chat_Img_S from '../Assets/chat_selected.png';
import Create_Img_S from '../Assets/create_selected.png';
import Notification_Img_S from '../Assets/notification_selected.png';
import Profile_Img_S from '../Assets/profile_selected.png';

const MainLayout = ({ userInfo, notificationCount, unreadChatCount }) => {
  const [selectedTab, setSelectedTab] = useState('home'); // Default selected tab

  const handleTabClick = (tab) => {
    setSelectedTab(tab);
  };

  return (
    <div className="layout">
      <header>
        <SearchBar />
      </header>

      <main>
        <Outlet />
      </main>

      <footer>
        <nav className='nav-bar'>
          <ul className='nav-list'>
            <li className='nav-item'>
              <Link to="/" onClick={() => handleTabClick('home')}>
                <img 
                  className="icon" 
                  src={selectedTab === 'home' ? Home_Img_S : Home_Img} 
                  alt="Home Icon" 
                />
                Home
              </Link>
            </li>
            <li className='nav-item'>
              <Link to="/chats" onClick={() => handleTabClick('chats')}>
                <img 
                  className="icon" 
                  src={selectedTab === 'chats' ? Chat_Img_S : Chat_Img} 
                  alt="Messages Icon" 
                />
                Messages {unreadChatCount > 0 && <div className='noti-alert'>{unreadChatCount}</div> }
              </Link>
            </li>
            <li className='nav-item'>
              <Link to="/create-post" onClick={() => handleTabClick('create')}>
                <img 
                  className="icon" 
                  src={selectedTab === 'create' ? Create_Img_S : Create_Img} 
                  alt="Create Post Icon" 
                />
                Create Post
              </Link>
            </li>
            <li className='nav-item'>
              <Link to="/notifications" onClick={() => handleTabClick('notifications')}>
                <img 
                  className="icon" 
                  src={selectedTab === 'notifications' ? Notification_Img_S : Notification_Img} 
                  alt="Notifications Icon" 
                />
                Notification {notificationCount > 0 && <span className='noti-alert'>{notificationCount}</span>}
              </Link>
            </li>
            <li className='nav-item'>
              <Link to="/profile" onClick={() => handleTabClick('profile')}>
                <img 
                  className="icon" 
                  src={selectedTab === 'profile' ? Profile_Img_S : Profile_Img} 
                  alt="Profile Icon" 
                />
                Profile
              </Link>
            </li>
          </ul>
        </nav>
      </footer>
    </div>
  );
};

export default MainLayout;
