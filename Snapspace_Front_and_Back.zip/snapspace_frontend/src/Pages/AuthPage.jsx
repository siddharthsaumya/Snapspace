import React, { useState } from 'react';
import Login from '../Components/Login/Login';
import Register from '../Components/Register/Register';
import './Auth.css';

function AuthPage() {
    // State to toggle between login and register
    const [isLogin, setIsLogin] = useState(true);

    // Toggle function
    const toggleAuthMode = () => {
        setIsLogin(!isLogin);
    };

    return (
<div className="auth-page-container">
  {isLogin ? (
    <>
      <Login />
      <p>
        Don't have an account?{' '}
        <button onClick={toggleAuthMode} className="toggle-button">
          Register here
        </button>
      </p>
    </>
  ) : (
    <>
      <Register />
      <p>
        Already have an account?{' '}
        <button onClick={toggleAuthMode} className="toggle-button">
          Login here
        </button>
      </p>
    </>
  )}
</div>
    );
}

export default AuthPage;
