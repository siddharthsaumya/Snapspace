import React, {useContext, useEffect, useState } from 'react';
import './NotFound.css';

function PageNotFound() {
    return (
      <div className='PageNotFoundContainer'>
        <h1 className="error-code">404</h1>
        <h2 className="error-message">Page Not Found</h2>
        <p className="error-description">
          Oops! It seems like you're lost. The page you're looking for doesn't exist.
        </p>
        <button className="home-button" onClick={() => window.location.href = '/'}>
          Take me home
        </button>
      </div>
    );
  }
  
  export default PageNotFound;