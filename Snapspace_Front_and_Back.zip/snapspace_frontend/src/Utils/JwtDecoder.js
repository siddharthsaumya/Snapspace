import {jwtDecode} from 'jwt-decode';

function JWTDecoder(token) {
    const decodedToken = jwtDecode(token);
    return decodedToken; 
}

export default JWTDecoder;
