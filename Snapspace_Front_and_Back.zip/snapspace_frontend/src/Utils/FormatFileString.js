export default function formatFileName(fileName) {
    if (typeof fileName !== 'string') {
      throw new Error('Invalid input: fileName must be a string');
    }
    const [baseName, extension] = fileName.split('.');
    if (!baseName || !extension) {
      throw new Error('Invalid fileName format');
    }
    const formattedExtension = extension.toUpperCase();
    return `${baseName} (${formattedExtension})`;
  }