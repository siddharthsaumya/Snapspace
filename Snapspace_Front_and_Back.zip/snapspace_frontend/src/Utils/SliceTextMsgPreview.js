export default function SliceTextMsgPreview(text) {
    if (text.length > 12) {
      return text.slice(0, 12) + '...';
    }
    return text;
  }
  