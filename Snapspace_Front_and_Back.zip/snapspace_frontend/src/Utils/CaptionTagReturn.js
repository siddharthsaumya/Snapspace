export function CaptionTagReturn(userId = '', text = '') {
  if (!text) return ''; // Handle undefined or null text

  // Split text by hashtags
  const parts = text.split(/(#\w+)/g);

  // Create HTML parts
  const htmlParts = parts.map(part => {
    if (part.startsWith('#')) {
      const tag = part.slice(1);
      return (
        `<a href="${`/tagged-posts/${encodeURIComponent(userId)}/${encodeURIComponent(tag)}`}" >#${tag}</a>`
      );
    }
    return part;
  });

  // Join HTML parts into a single string
  return htmlParts.join('');
}