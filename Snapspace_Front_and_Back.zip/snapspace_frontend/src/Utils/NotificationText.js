export function getNotificationMessage(notificationType, username) {
    switch (notificationType) {
        case 0:
            return `${username} sent you a follow request`;
        case 1:
            return `${username} started following you`;
        case 2:
            return `You started following ${username}`;
        case 3:
            return `${username} liked your post`;
        case 4:
            return `${username} commented on your post`;
        default:
            return "Unknown notification type";
    }
}