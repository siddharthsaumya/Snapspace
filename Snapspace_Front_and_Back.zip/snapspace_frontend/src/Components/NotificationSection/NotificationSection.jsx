import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { baseUrl } from '../../Server';
import { timeDifferenceFromNow } from '../../Utils/DateTimeFunctions';
import { getNotificationMessage } from '../../Utils/NotificationText';
import FollowRequestComponent from '../FollowRequestComponent/FollowRequestComponent';
import './NotificationSection.css';
import Default_Pfp from '../../Assets/Default_Pfp.png';

const NotificationSection = ({ userInfo }) => {
  const [notificationList, setNotificationList] = useState([]);
  const [userData, setUserData] = useState(null);
  const [pendingRequestsList, setPendingRequestsList] = useState([]);
  const navigate = useNavigate();
  // Set the user data from props
  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  // Fetch follow requests
  const getFollowRequests = () => {
    axios
      .get(`${baseUrl}/${userData.id}/get-pending-requests`)
      .then(response => {
        setPendingRequestsList(response.data.pendingRequests);
      })
      .catch(e => {
        if (e.response.data.statusCode == 404) setPendingRequestsList([])
        else console.error("Cannot get pending requests API:", e.response?.data || e.message);
      });
  };

  // Fetch notifications and follow requests when userData is set
  useEffect(() => {
    if (userData) {
      axios
        .get(`${baseUrl}/${userData.id}/get-notifications`)
        .then(response => {
          setNotificationList(response.data.notifications);
        })
        .catch(e => {
          console.error("Cannot get notifications API:", e.response?.data || e.message);
        });

      getFollowRequests();
    }
  }, [userData]); // This effect depends on userData

  const handleNavigateLink = (type, source) => {
    if(type <= 2) navigate('/profile/'+userData.id+'/'+source);
    else navigate('/post/'+userData.id+'/'+source);
  }

  return (
    <div className="container">

<div className="follow-requests">
      {pendingRequestsList.length > 0 && <div className="follow-requests-header">You have {pendingRequestsList.length} pending follow requests</div>}
      {pendingRequestsList.length > 0 ? (
        <FollowRequestComponent
          userInfo={userData}
          pendingRequestsList={pendingRequestsList}
          getFollowRequests={getFollowRequests}
        />
      ) : (
        <div className="no-requests">No Pending Follow Requests</div>
      )}
    </div>
    
    <div className="notifications">
      {notificationList.length > 0 ? (
        notificationList
          .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
          .map(notification => (
            <div
              key={notification.id}
              className="notification-item"
              onClick={() => handleNavigateLink(notification.notificationType, notification.sourceId)}
            >
              <img
                src={notification.user.profilePicture || Default_Pfp}
                alt={`${notification.user.username}'s profile`}
                className="notification-avatar"
              />
              <div className="notification-content">
                <div className="notification-message">
                  {getNotificationMessage(notification.notificationType, notification.user.username)}
                </div>
                <div className="notification-time">
                  {timeDifferenceFromNow(notification.createdAt)} Ago
                </div>
              </div>
            </div>
          ))
      ) : (
        <div className="no-notifications">No Notifications Yet</div>
      )}
    </div>
  
    
  </div>
  
  );
};

export default NotificationSection;
