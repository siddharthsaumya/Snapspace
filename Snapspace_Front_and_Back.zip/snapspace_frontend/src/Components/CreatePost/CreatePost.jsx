import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import { baseUrl } from '../../Server';
import CookiesService from '../../Services/CookiesService';
import JWTDecoder from '../../Utils/JwtDecoder';
import './CreatePost.css';
import formatFileName from '../../Utils/FormatFileString';

const CreatePost = ({ userInfo }) => {
  const navigate = useNavigate();
  const [postUrl, setPostUrl] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [postCaption, setPostCaption] = useState("");
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filePreview, setFilePreview] = useState(null); // File preview

  useEffect(() => {
    if (userInfo && userInfo.id != null) {
      setUserData(userInfo);
      setLoading(false);
    } else {
      if (CookiesService.isAuthenticated()) {
        const DToken = JWTDecoder(CookiesService.getToken());
        axios.get(`${baseUrl}/${DToken.nameid}/get-user/${DToken.nameid}`)
          .then(response => {
            setUserData(response.data.userDto);
            setLoading(false);
          })
          .catch(e => {
            setError("Cannot get user info from API");
            setLoading(false);
            console.error("Cannot get user info api:", e.response.data);
          });
      } else {
        setLoading(false);
      }
    }
  }, [userInfo]);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
    setFilePreview(URL.createObjectURL(file)); // Preview the selected image
  };

  const handleCaptionChange = (event) => {
    setPostCaption(event.target.value);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert("Please select a file first.");
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    try {
      const response = await axios.post(baseUrl + '/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setPostUrl(response.data.url);

      await axios.post(baseUrl + '/create-post', {
        "userId": userData.id,
        "imageUrl": response.data.url,
        "caption": postCaption
      });

      alert("Post created successfully");
      navigate("/profile");
    } catch (error) {
      console.error('There was an error uploading the file!', error);
    }
  };

  return (
    <div className="create-post-container">

{filePreview && (
        <div className="image-preview">
          <img src={filePreview} alt="Selected file preview" />
        </div>
      )}

      <label htmlFor="file-upload" className="custom-file-upload">
        {selectedFile ? `${formatFileName(selectedFile.name)}` : 'Choose Photo'}
      </label>
      <input id="file-upload" type="file" onChange={handleFileChange} />



      <input
        type="text"
        placeholder="Write a caption..."
        value={postCaption}
        onChange={handleCaptionChange}
      />

      {loading ? (
        <p>Loading...</p>
      ) : (
        <button onClick={handleUpload} disabled={!selectedFile || !postCaption}>
          Share
        </button>
      )}

      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default CreatePost;
