import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import CookiesService from '../../Services/CookiesService';
import './DeactivateDeleteUser.css';

const DeactivateDeleteUser = ({ userInfo, handleLogout }) => {
  const [userData, setUserData] = useState(null);
  const [password, setPassword] = useState('');

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  const handleDeactivateUser = async () => {
    try {
      await axios.patch(
        `${baseUrl}/${userData.id}/deactivate-user`,
        { password: password },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      alert('User Deactivated');
      handleLogout();
    } catch (error) {
      if (error.response.data.statusCode == 1001) alert('Wrong password');
      else console.error('Error deactivating account', error.response);
    }
  };

  const handleDeleteUser = async () => {
    try {
      await axios.post(`${baseUrl}/${userData.id}/logout`);
      await axios.delete(
        `${baseUrl}/${userData.id}/delete-user`,
        {
          data: { password: password }, // Send body here
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
    CookiesService.removeToken();
    window.location.href = '/';
    } catch (error) {
      if (error.response?.data?.statusCode === 1001) alert('Wrong password');
      else console.error('Error deleting account', error.response);
    }
  };

  return (
<div className="account-actions-container">
  <input
    type="password"
    placeholder="Enter password..."
    onChange={(e) => setPassword(e.target.value)}
    className="password-input"
  />
  <button onClick={handleDeactivateUser} className="action-button deactivate">
    Deactivate Account
  </button>
  <button onClick={handleDeleteUser} className="action-button delete">
    Delete Account
  </button>
</div>
  );
};

export default DeactivateDeleteUser;
