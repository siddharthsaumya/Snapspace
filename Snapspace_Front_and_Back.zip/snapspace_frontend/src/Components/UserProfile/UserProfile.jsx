import React, { useEffect, useState } from 'react';
import axios from 'axios';
import JWTDecoder from '../../Utils/JwtDecoder';
import { baseUrl } from '../../Server';
import CookiesService from '../../Services/CookiesService';
import UserProfileInfo from '../UserProfileInfo/UserProfileInfo';
import ActionButtons from '../ActionButtons/ActionButtons';
import Default_Post from '../../Assets/Default_Post.png';
import UpdateProfile from '../UpdateProfile/UpdateProfile';
import Setting_Img from '../../Assets/setting.png';
import './UserProfile.css';

const UserProfile = ({ myUserId, userData }) => {
  const [ownProfile, setOwnProfile] = useState(false);
  const [profileType, setProfileType] = useState("");
  const [userInformation, setUserInformation] = useState(null);
  const [loadedImages, setLoadedImages] = useState({});

  useEffect(() => {        
          setUserInformation(userData);
          setOwnProfile(userData.ownAccount);
          setProfileType(userData.profileType);
  }, []);

  const handleImageLoad = (index) => {
    setLoadedImages((prevState) => ({
      ...prevState,
      [index]: true,
    }));
  };

  const handleImageError = (e, index) => {
    e.target.src = Default_Post;
    setLoadedImages((prevState) => ({
      ...prevState,
      [index]: false,
    }));
  };

  // Render Loading message until userInformationOwn is set
  if (!userInformation) return <div>Loading...</div>;

  return (
<div className='user-profile-page' style={{overflowX: 'hidden'}}>
  {ownProfile && (
    <button className='setting-btn' onClick={() => (window.location.href = '/setting')}>
      <img style={{width: '15px', height: '15px'}} src={Setting_Img} alt='Settings Icon' />
      Setting
    </button>
  )}
  
  <UserProfileInfo userData={userInformation} myUserId={myUserId} />
  
  <ActionButtons
    ownProfile={ownProfile}
    buttonType={profileType}
    myUserId={myUserId}
    targetId={userInformation.id}
  />
  
  <div className='posts-container'>
    {(ownProfile || profileType === 'FOLLOW') ? (
      userInformation.posts.length > 0 ? (
        userInformation.posts.map((post, index) => (
          <a
            key={index}
            href={
              myUserId === userInformation.id || myUserId === undefined 
                ? `/post/${userInformation.id}/${post.id}` 
                : `/post/${myUserId}/${post.id}`
            }
          >
            <img
              src={post.imageUrl}
              onLoad={() => handleImageLoad(index)}
              onError={(e) => handleImageError(e, index)}
              className='post-image'
              alt={`Post ${index}`}
            />
          </a>
        ))
      ) : (
        <div className='blank-post'>NO POST</div>
      )
    ) : (
      <div className='blank-post'>POSTS ARE PRIVATE</div>
    )}
  </div>
</div>

  );
};

export default UserProfile;
