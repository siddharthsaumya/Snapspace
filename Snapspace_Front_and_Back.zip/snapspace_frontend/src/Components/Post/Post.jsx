import React, { useState, useEffect,useRef } from 'react';
import { formatDate } from '../../Utils/DateTimeFunctions';
import { CaptionTagReturn } from '../../Utils/CaptionTagReturn';
import { baseUrl } from '../../Server';
import axios from 'axios';
import CommentBox from '../CommentBox/CommentBox';
import Default_Pfp from '../../Assets/Default_Pfp.png'
import Like_Img from '../../Assets/like.png';
import Liked_Img from '../../Assets/liked.png';
import Comment_Img from '../../Assets/comment.png';
import './Post.css';
import Option_Img from '../../Assets/options_icon.png';
import Edit_Img from '../../Assets/edit.png';
import Archive_Img from '../../Assets/archive.png';
import Delete_Img from '../../Assets/delete.png';


const Post = ({ postInfo, userId, isPostArchived }) => {
  const [isLiked, setIsLiked] = useState(postInfo.isLiked);
  const [likeCount, setLikeCount] = useState(postInfo.likeCount);
  const [isCommentBoxOpen, setIsCommentBoxOpen] = useState(false);
  const [commentsList, setCommentsList] = useState([]);
  const [ownPost, setOwnPost] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [newCaption, setNewCaption] = useState(postInfo.caption);
  const [isArchived, setIsArchived] = useState(postInfo.isArchived);
  const [isOptionsOpen, setIsOptionsOpen] = useState(false);

  useEffect(() => {
    if (postInfo) {
      setIsLiked(postInfo.isLiked);
      setLikeCount(postInfo.likeCount);
      setIsArchived(postInfo.isArchived); 
      if (postInfo.userId == userId) setOwnPost(true);
    }
  }, [postInfo, commentsList]);

    const toggleOptions = () => {
      setIsOptionsOpen(!isOptionsOpen);
    };

  const TogglePostLike = async () => {
    try {
      await axios.post(`${baseUrl}/toggle-like`, {
        postId: postInfo.id,
        userId: userId,
      });

      setIsLiked((prev) => !prev);
      setLikeCount((prevCount) => (isLiked ? prevCount - 1 : prevCount + 1));
    } catch (error) {
      console.error('Error liking the post:', error);
    }
  };

  const loadComments = () => {
    axios.get(`${baseUrl}/${postInfo.id}/get-comments`)
      .then(response => {
        setCommentsList(response.data.commentDtos);
      })
      .catch(e => {
        console.error("Cannot get chat list api:", e.response.data);
      });
  }

  const toggleCommentBox = () => {
    setIsCommentBoxOpen((prev) => !prev);
    loadComments();
  };

  const handleEdit = () => {
    setIsEditing(!isEditing);
  };

  const handleSaveChanges = async () => {
    try {
      await axios.patch(`${baseUrl}/${postInfo.id}/update-caption`, { newCaption });
      postInfo.caption = newCaption;
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating the caption:', error);
    }
  };

  const handleToggleArchive = async () => {
    try {
      await axios.patch(`${baseUrl}/${postInfo.id}/toggle-archive`);
      setIsArchived((prev) => !prev);
    } catch (error) {
      console.error('Error toggling archive:', error);
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`${baseUrl}/${userId}/delete-post/${postInfo.id}`);
      window.location.href = '/profile';
    } catch (error) {
      console.error('Error deleting the post:', error);
    }
  };

  if (isArchived) {
    return <div style={{ backgroundColor: "#ffb4b4", padding: '10px', marginBottom: '10px', borderRadius: '5px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', width:'60vw', margin: 'auto auto' }}>
    <p style={{ margin: '0', fontWeight: 'bold' }}>{ isPostArchived ? 'POST UNARCHIVED' : 'POST ARCHIVED' }</p>
    <button style={{ backgroundColor: '#3498db', color: 'white', padding: '8px 12px', border: 'none', borderRadius: '5px', cursor: 'pointer', transition: 'background-color 0.2s ease-in-out' }} onClick={()=>{ window.location.href = '/profile';}}>Go To Profile</button>
  </div>;
  }

  return (
    <div className='post-container'>
      <div className='profile-section'>
        <div className="profile-picture-container">
        <img
          src={postInfo.profilePicture || Default_Pfp}
          alt="Profile Picture"
        />
        </div>
        <a href={'/profile/' + userId + '/' + postInfo.userId}
        className='username'
        >
          {postInfo.username}
        </a>

        {ownPost && (
        <div className='options-container'>

{isOptionsOpen && (
            <div className="options-box">
              <img className='edit-btn' src={Edit_Img} onClick={() => {handleEdit();toggleOptions();}}/>
              <img className='archive-btn' src={Archive_Img} onClick={() => {handleToggleArchive();toggleOptions();}}/>
              <img className='delete-btn' src={Delete_Img} onClick={() => {handleDelete();toggleOptions();}}/>
            </div>
          )}

          <img
            src={Option_Img}
            alt="Options"
            className="options-icon"
            onClick={toggleOptions}
          />


        </div>
      )}


      </div>
      <img
        src={postInfo.imageUrl}
        className='post-image'
        alt="Post"
      />
      <div className='lc-actions'>
        {isLiked ? (
          <img src={Liked_Img} className='like' onClick={TogglePostLike} />
        ) : (
          <img src={Like_Img} className='like' onClick={TogglePostLike} />
        )}
        <span className='like-count'>{likeCount || 0}</span>
        <img className='comment' src={Comment_Img} onClick={toggleCommentBox} />
        <span className='comment-count'>{postInfo.commentCount}</span>
      </div>

      {isCommentBoxOpen && (
        <CommentBox
          commentsList={commentsList}
          isFollowed={postInfo.followPostUser}
          postId={postInfo.id}
          userId={userId}
          onClose={toggleCommentBox}
          loadComments={loadComments}
          setCommentsList={setCommentsList}
        />
      )}
      
      {isEditing ? (
        <div className='update-container'>
  <input
    type="text"
    className='update-input'
    value={newCaption}
    onChange={(e) => setNewCaption(e.target.value)}
  />
  <button className='update-btn' onClick={handleSaveChanges}>Save</button>
</div>

      ) : (
        <p className='caption' dangerouslySetInnerHTML={{ __html: CaptionTagReturn(userId, postInfo.caption) }} />
      )}

    <p className='date'>{formatDate(postInfo.createdAt)}</p>
    </div>
  );
};

export default Post;
