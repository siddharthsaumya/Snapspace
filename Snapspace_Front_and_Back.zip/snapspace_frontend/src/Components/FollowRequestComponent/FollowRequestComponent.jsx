import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import {timeDifferenceFromNow} from '../../Utils/DateTimeFunctions';
import {getNotificationMessage} from '../../Utils/NotificationText';
import '../NotificationSection/NotificationSection.css';
import Default_Pfp from '../../Assets/Default_Pfp.png';

const FollowRequestComponent = ({ userInfo, pendingRequestsList, getFollowRequests }) => {
  
    const rejectFollowRequest = (Id) => {
        axios.patch(`${baseUrl}/${userInfo.id}/reject-follow-request/${Id}`)
        .then(response => {
            getFollowRequests();
        })
        .catch(e => {
          console.error("Cannot reject follow request API:", e.response.data);
        });
    }

    const acceptFollowRequest = (Id) => {
        axios.patch(`${baseUrl}/${userInfo.id}/accept-follow-request/${Id}`)
        .then(response => {
            getFollowRequests();
        })
        .catch(e => {
          console.error("Cannot accept follow request API:", e.response.data);
        });
    }
  
    return (
<div className='follow-requests-content'>
  <div className='requests-list'>
    {pendingRequestsList.length > 0 ? (
      pendingRequestsList.map((request) => (
        <div key={request.id} className='request-item'>
          <img src={request.profilePicture || Default_Pfp} className='profile-picture' />
          <div className='user-info'>
            <div className='username'>{request.username}</div>
            <div className='full-name'>{request.fullName}</div>
          </div>
          <button className='reject-button' onClick={() => rejectFollowRequest(request.id)}>Reject</button>
          <button className='accept-button' onClick={() => acceptFollowRequest(request.id)}>Accept</button>
        </div>
      ))
    ) : (
      <h3 className='no-requests'>No Pending Follow Requests</h3>
    )}
  </div>
</div>

  );
};

// const styles = {
//   container: {
//     position: 'fixed',
//     top: '100px',
//     right: '20px',
//     width: '300px',
//     backgroundColor: '#fff',
//     boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
//     borderRadius: '8px',
//     zIndex: 1000,
//     padding: '10px',
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: '10px',
//   },
//   closeButton: {
//     background: 'transparent',
//     border: 'none',
//     cursor: 'pointer',
//     fontSize: '18px',
//   },
//   body: {
//     maxHeight: '300px',
//     overflowY: 'auto',
//   },
//   request: {
//     display: 'flex',
//     alignItems: 'center',
//     marginBottom: '10px',
//   },
//   profilePic: {
//     width: '40px',
//     height: '40px',
//     borderRadius: '50%',
//     marginRight: '10px',
//   },
//   time: {
//     fontSize: '12px',
//     color: 'gray',
//   },
// };

export default FollowRequestComponent;

