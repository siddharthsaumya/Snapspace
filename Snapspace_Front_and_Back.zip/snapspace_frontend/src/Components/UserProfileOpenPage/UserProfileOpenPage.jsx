import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import JWTDecoder from '../../Utils/JwtDecoder';
import { baseUrl } from '../../Server';
import { UserContext } from '../../Context/UserInfoContext';
import CookiesService from '../../Services/CookiesService';
import Post from '../Post/Post';
import UserProfileInfo from '../UserProfileInfo/UserProfileInfo';
import UserProfile from '../UserProfile/UserProfile';
import {useParams,useNavigate } from "react-router-dom";

const UserProfileOpenPage = () => {
    const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userInformationOwn, setUserInformationOwn] = useState(null);
  let { targetuserid } = useParams();
  let { userid } = useParams();

  useEffect(() => {
    const fetchPosts = async () => {
        try {
            axios.get(`${baseUrl}/${userid}/get-user/${targetuserid}`)
            .then(response => {
              const userInformation = response.data.userDto;
              if (userInformation.id === userid) navigate("/profile");;
              setUserInformationOwn(userInformation);
            })
            .catch(e => {
              console.error("Cannot get user info api:", e.response.data);
            });
          //setPosts(userInformationOwn.posts);
        } catch (error) {
          console.error('Error fetching posts:', error);
        } finally {
          setLoading(false);
        }
    };

    fetchPosts();
  }, [userInformationOwn]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error loading profile: {error}</p>;

  return (
    <div>
      {userInformationOwn ? (
        <UserProfile myUserId={userid} userData={userInformationOwn} />
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
};

export default UserProfileOpenPage;
