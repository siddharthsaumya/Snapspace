import React, { useState, useEffect } from 'react';
import Post from '../Post/Post';
import {useParams} from "react-router-dom";
import { baseUrl } from '../../Server';
import axios from 'axios';

const PostByTag = () => {
    let { tagname } = useParams();
    let { userid } = useParams();
    const [postInfo, setPostInfo] = useState([]);

    useEffect(() => {
        axios.get(`${baseUrl}/${userid}/get-posts-by-tag/${tagname}`)
        .then(response => {
            if(response.data.statusCode == 200){
                setPostInfo(response.data.posts);
            }
        })
        .catch(e => {
          console.error("Cannot get chat list api:", e.response.data);
        });
      }, [postInfo]);

  return (
    <div>
    {postInfo.map((post, index) => (
        <Post className='post' key={index} userId={userid} postInfo={post} />
    ))}
    </div>
  );
};

export default PostByTag;
