import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import JWTDecoder from '../../Utils/JwtDecoder';
import { baseUrl } from '../../Server';
import { UserContext } from '../../Context/UserInfoContext';
import CookiesService from '../../Services/CookiesService';
import Post from '../Post/Post';
import UserProfileInfo from '../UserProfileInfo/UserProfileInfo';
import UserProfile from '../UserProfile/UserProfile';

const ProfileSection = ({userInfo}) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  useEffect(() => {
    const fetchPosts = async () => {
      if (userData && userData.id) {
        try {
          setPosts(userData.posts);
        } catch (error) {
          console.error('Error fetching posts:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchPosts();
  }, [userData]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error loading profile: {error}</p>;

  return (
    <div>
      {userData ? (
        <UserProfile userData={userData} />
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
};

export default ProfileSection;
