import React, { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import CookiesService from '../../Services/CookiesService';
import './Login.css';

function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({
        username: '',
        password: '',
    });

    const validateUsername = (username) => {
        if (!username) {
            return 'Username is required';
        } else if (username.length > 50) {
            return 'Username too long';
        } else if (!/^[a-zA-Z0-9._]+$/.test(username)) {
            return 'Username can only contain letters, numbers, ., and _';
        }
        return '';
    };

    const validatePassword = (password) => {
        const passwordErrors = [];
        
        if (!password) {
            passwordErrors.push('Password is required');
        }
        if (password.length < 8) {
            passwordErrors.push('Password must be at least 8 characters long');
        }
        if (!/[A-Z]/.test(password)) {
            passwordErrors.push('Password must contain at least one uppercase letter');
        }
        if (!/[a-z]/.test(password)) {
            passwordErrors.push('Password must contain at least one lowercase letter');
        }
        if (!/\d/.test(password)) {
            passwordErrors.push('Password must contain at least one number');
        }
        if (!/[@$!%*?&]/.test(password)) {
            passwordErrors.push('Password must contain at least one special character (@, $, !, %, *, ?, &)');
        }
        
        return passwordErrors;
    };

    const handleLogin = async (e) => {
        e.preventDefault();

        const newErrors = {
            username: validateUsername(username),
            password: validatePassword(password),
        };

        setErrors(newErrors);

        if (Object.values(newErrors).some((error) => error.length > 0)) {
            return;
        }

        const userData = {
            username,
            password
        };

        try {
            const response = await axios.post(baseUrl + '/login', userData);
            console.log('Login successful:', response.data.token);
            CookiesService.setToken(response.data.token, response.data.expiration);
            window.location.href = "/";
        } catch (error) {
            const statusCode = error.response?.data?.statusCode || 0;
            if (statusCode === 404) {
                alert('User not found');
                console.log("USER NOT FOUND");
            } else if (statusCode === 1001) {
                alert('Password does not match');
                console.log("PASSWORD DOES NOT MATCH");
            } else {
                alert('An unexpected error occurred');
                console.log("An unexpected error occurred:", error);
            }
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleLogin(e);
        }
    };

    return (
<div className="login-container">
  <h2 className="login-heading">Login</h2>
  <form className="login-form" onSubmit={handleLogin}>
    <div className="input-container">
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => {
          setUsername(e.target.value);
          setErrors((prevErrors) => ({
            ...prevErrors,
            username: validateUsername(e.target.value),
          }));
        }}
        onBlur={() => setErrors((prevErrors) => ({
          ...prevErrors,
          username: validateUsername(username),
        }))}
        className="input-field"
        required
      />
      {errors.username && <div className="error">{errors.username}</div>}
    </div>
    <div className="input-container">
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          setErrors((prevErrors) => ({
            ...prevErrors,
            password: validatePassword(e.target.value),
          }));
        }}
        onBlur={() => setErrors((prevErrors) => ({
          ...prevErrors,
          password: validatePassword(password),
        }))}
        onKeyPress={handleKeyPress}
        className="input-field"
        required
      />
      {errors.password &&
        errors.password.map((error, index) => (
          <div key={index} className="error">{error}</div>
        ))}
    </div>
    <button type="submit" className="login-button">
      Login
    </button>
  </form>
  <button onClick={() => (window.location.href = "/forgot-password")}>
    Forgot Password
  </button>
</div>
    );
}

export default Login;
