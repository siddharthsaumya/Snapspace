import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import JWTDecoder from '../../Utils/JwtDecoder';
import { baseUrl } from '../../Server';
import { UserContext } from '../../Context/UserInfoContext';
import CookiesService from '../../Services/CookiesService';
import Post from '../Post/Post';
import './Feed.css';

const Feed = ({userInfo}) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userData, setUserData] = useState(null);

  // const userInfo = useContext(UserContext);

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  useEffect(() => {
    // if (userInfo == null) {
    //   if (CookiesService.isAuthenticated()) {
    //     const DToken = JWTDecoder(CookiesService.getToken());
    //     axios.get(`${baseUrl}/${DToken.nameid}/get-user/${DToken.nameid}`)
    //       .then(response => {
    //         setUserData(response.data.userDto);
    //       })
    //       .catch(e => {
    //         console.error("Cannot get user info api:", e.response.data);
    //       });
    //   }
    // }

    const fetchPosts = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`${baseUrl}/${userData?.id}/get-feed`);
        setPosts(response.data.posts);
      } catch (error) {
        const errorMessage = error.response?.data?.statusCode || 'An unexpected error occurred.';
        if (errorMessage == 404) setError("Seems like you don't follow anyone yet");
        else setError("Error loading posts: ",errorMessage);
        console.error('Error fetching posts:', errorMessage);
      } finally {
        setLoading(false);
      }
    };

    if (userData?.id) {
      fetchPosts();
    }
  }, [userData]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p className='no-post' >{error}</p>;

  return (
    <div className='feed'>
      {posts.map((post, index) => (
        <Post className='post' key={index} userId={userData.id} postInfo={post}/>
      ))}
    </div>
  );
};

export default Feed;
