import React, { useState } from 'react';
import Default_PFP from '../../Assets/Default_Pfp.png';
import PeopleConnectionList from '../PeopleConnectionList/PeopleConnectionList';
import { baseUrl } from '../../Server';
import axios from 'axios';
import './UserProfileInfo.css';

const UserProfileInfo = ({ userData, myUserId }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [pcList,setPcList] = useState([]);
  const [pcListType, setPcListType] = useState('');
  const [pcListOpen, setPcListOpen] = useState(false);

  const openPcList = (pcType) => {
    setPcListType(pcType);
    var type = '';
    if(pcType == 'FOLLOWER') type = 'get-followers';
    else type = 'get-followings';
        axios.get(`${baseUrl}/${userData.id}/${type}`)
            .then(response => {
                if(pcType == 'FOLLOWER') setPcList(response.data.followerUsers);
                else setPcList(response.data.followingUsers);
            })
            .catch(e => {
                if(e.response.data.statusCode == 404) setPcList([]);
                else console.error("Cannot get user info api:", e.response.data);
            });

            if(myUserId == userData.id) setPcListOpen(true);
            else {
                axios.get(`${baseUrl}/${myUserId}/is-following/${userData.id}`)
                .then(response => {
                  if(response.data.statusCode == 200 && response.data.isFollowing == true) setPcListOpen(true);
                  else if (response.data.statusCode == 200 && response.data.isFollowing == false) setPcListOpen(false);
                })
                .catch(e => {
                    if(e.response.data.status == 400) setPcListOpen(true);
                    else console.error("Cannot get user info api:", e.response.data.status);
                });
            }
  }

  return (
      <div className='user-info-section'>
        {pcListOpen && <PeopleConnectionList pcList={pcList} pcListType={pcListType} userInfo={userData} setPcListOpen={setPcListOpen} />}
          <div className='username'>{userData.username}</div>
          <div className='pfp-container'>
          <img
              src={userData.profilePicture || Default_PFP}
              alt="Profile"
              className='profile-picture'
              onLoad={() => setIsLoaded(true)}
              onError={() => setIsLoaded(false)}
          />
          </div>
          <div className='count-info'>
          <span className='post-count'>{userData.postCount}<br/>posts</span>
          <span className='follower-count' onClick={() => openPcList('FOLLOWER')}>{userData.followerCount}<br/>followers</span>
          <span className='following-count' onClick={() => openPcList('FOLLOWING')}>{userData.followingCount}<br/>followings</span>
          </div>
          <div className='full-name'>{userData.fullName}</div>
          <div className='bio'>{userData.bio}</div>

        </div>
  );
};

export default UserProfileInfo;