import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import './UpdateSecurityQuestion.css';

const UpdateSecurityQuestion = ({ userInfo }) => {
  const [userData, setUserData] = useState(null);
  const [questionsList, setQuestionsList] = useState([]);
  const [selectedQuestion, setSelectedQuestion] = useState(''); // For storing selected question text
  const [selectedQuestionId, setSelectedQuestionId] = useState(0); // For storing selected question ID
  const [selectedQuestionOther, setSelectedQuestionOther] = useState('');
  const [selectedAnswer, setSelectedAnswer] = useState('');

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  const fetchQuestions = () => {
    axios.get(`${baseUrl}/get-all-questions`)
      .then(response => {
        setQuestionsList(response.data.questions);
      })
      .catch(e => {
        console.error("Cannot get questions list API:", e.response.data);
      });
  }
  useEffect(() => {
    fetchQuestions();
  }, []);

  const handleQuestionChange = (event) => {
    const selectedIndex = event.target.selectedIndex;
    const questionId = event.target.options[selectedIndex].getAttribute('data-id');
    const questionText = event.target.value;
    
    setSelectedQuestion(questionText);
    setSelectedQuestionId(questionId);
  };

  const addSecurityQuestion = async () => {
    await axios.post(`${baseUrl}/${userData.id}/add-question`, {"question": selectedQuestionOther})
      .then(response => {
        fetchQuestions();
        alert("Security Question Added");
        setSelectedQuestion('');
        setSelectedQuestionOther('');
      })
      .catch(error => {
        console.error(error);
      });
  }

  const updateSecurityQuestionAnswer = async () => {
    await axios.patch(`${baseUrl}/${userData.id}/update-question-answer`, {
        "securityQuestionId": selectedQuestionId,
        "securityAnswer": selectedAnswer
      })
      .then(response => {
        alert("Security Question Answer Updated");
        setSelectedQuestion('');
        setSelectedAnswer('');
      })
      .catch(error => {
        console.error(error);
      });
  }

  return (
<div className="security-question-container">
  <label htmlFor="security-question">Select a security question:</label>
  <select
    id="security-question"
    value={selectedQuestion}
    onChange={handleQuestionChange}
  >
    <option value="">-- Select a question --</option>
    {questionsList.length > 0 && questionsList.map((question) => (
      <option key={question.id} value={question.question} data-id={question.id}>
        {question.question}
      </option>
    ))}
    <option value="Other">Other</option>
  </select>

  {selectedQuestion === 'Other' && (
    <div className="additional-question">
      <input
        type="text"
        value={selectedQuestionOther}
        onChange={(e) => setSelectedQuestionOther(e.target.value)}
        placeholder="Write new security question..."
        required
      />
      <button onClick={addSecurityQuestion}>Add Question</button>
    </div>
  )}

  <div className="update-answer">
    <input
      type="text"
      value={selectedAnswer}
      onChange={(e) => setSelectedAnswer(e.target.value)}
      placeholder="Write new security answer..."
      required
    />
    <button onClick={updateSecurityQuestionAnswer}>Update</button>
  </div>
</div>

  );
};

export default UpdateSecurityQuestion;
