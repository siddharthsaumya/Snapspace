import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import CookiesService from '../../Services/CookiesService';
import SentRequestSection from '../SentRequestSection/SentRequestSection';
import ArchivedPosts from '../ArchivedPosts/ArchivedPosts';
import UpdateSecurityQuestion from '../UpdateSecurityQuestion/UpdateSecurityQuestion';
import UpdatePassword from '../UpdatePassword/UpdatePassword';
import DeactivateDeleteUser from '../DeactivateDeleteUser/DeactivateDeleteUser';
import OnlineStatusToggle from '../OnlineStatusToggle/OnlineStatusToggle';
import './SettingSection.css';
import Hi_Ghost_Img from '../../Assets/hi_by_ghost.png';

const SettingSection = ({ userInfo }) => {
  const [userData, setUserData] = useState(null);
  const [selectedSection, setSelectedSection] = useState('');

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  const handleLogout = async () => {
    console.log('Logging out...');
    await axios.post(`${baseUrl}/${userData.id}/logout`);
    CookiesService.removeToken();
    localStorage.removeItem("userData");
    window.location.href = '/';
  }

  const selectSection = (section) => {
    setSelectedSection(section);
  }

  return (
  <div className="user-settings-container">
  {/* Left Panel for buttons */}
  <div className="left-panel">
    <button onClick={() => selectSection('SENT REQUESTS')}>Sent Requests</button>
    <button onClick={() => selectSection('ARCHIVED POSTS')}>Archived Posts</button>
    <button onClick={() => selectSection('UPDATE SECURITY QUESTION')}>Update Security Question</button>
    <button onClick={() => selectSection('UPDATE PASSWORD')}>Update Password</button>
    <OnlineStatusToggle userInfo={userData} onColor="#06D6A0" className="online-status-toggle" />
    <button className='logout' onClick={handleLogout}>Log Out</button>
    <button className='delete' onClick={() => selectSection('DEACTIVATE-DELETE')}>Deactivate/Delete Account</button>
  </div>

  {/* Right Panel for opened section */}
  <div className="right-panel">
  <div className="opened-section">
  {selectedSection === 'SENT REQUESTS' ? (
    <SentRequestSection userInfo={userData} />
  ) : selectedSection === 'ARCHIVED POSTS' ? (
    <ArchivedPosts userInfo={userData} />
  ) : selectedSection === 'UPDATE SECURITY QUESTION' ? (
    <UpdateSecurityQuestion userInfo={userData} />
  ) : selectedSection === 'UPDATE PASSWORD' ? (
    <UpdatePassword userInfo={userData} handleLogout={handleLogout} />
  ) : selectedSection === 'DEACTIVATE-DELETE' ? (
    <DeactivateDeleteUser userInfo={userData} handleLogout={handleLogout} />
  ) : (
    <div className="empty-image-container">
      <img className="empty-page-img" src={Hi_Ghost_Img} />
    </div>
  )}
</div>

  </div>
</div>

  );
};

export default SettingSection;
