import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { baseUrl } from '../../Server';
import './ForgotPassword.css';

const ForgotPassword = () => {
    const [username, setUsername] = useState('');
    const [userId, setUserId] = useState(null);
    const [securityQuestion, setSecurityQuestion] = useState('');
    const [securityAnswer, setSecurityAnswer] = useState('');
    const [attempts, setAttempts] = useState(3);
    const [isVerified, setIsVerified] = useState(false);
    const [isQuestionRetrieved, setIsQuestionRetrieved] = useState(false);
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [currentPassword, setCurrentPassword] = useState(null);
    const [passwordErrors, setPasswordErrors] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {}, [attempts]);

    const handleGetSecurityQuestion = async () => {
        try {
            const response = await axios.get(`${baseUrl}/${username}/get-security-question`);

            if (response.data.statusCode == 200) {
                setSecurityQuestion(response.data.securityQuestion);
                setIsQuestionRetrieved(true);
            } else {
                alert('Username not found.');
            }
        } catch (error) {
            console.error('Error retrieving security question', error);
            alert('Username not found.');
        }
    };

    const handleCheckAnswer = async () => {
        if (attempts === 0) {
            navigate('/auth');
            return;
        }

        try {
            const response = await axios.post(`${baseUrl}/verify-security-answer`, {
                username,
                answer: securityAnswer,
            });

            if (response.data.result) {
                setIsVerified(true);
                setCurrentPassword(response.data.password);
                setUserId(response.data.userId);
            } else {
                alert('Wrong answer. Please try again.');
                setAttempts(attempts - 1);
            }
        } catch (error) {
            console.error('Error verifying answer', error);
            alert('Wrong answer. Please try again.');
            setAttempts(attempts - 1);
        }
    };

    const validatePassword = (password) => {
        const passwordErrors = [];
        
        if (!password) {
            passwordErrors.push('Password is required');
        }
        if (password.length < 8) {
            passwordErrors.push('Password must be at least 8 characters long');
        }
        if (!/[A-Z]/.test(password)) {
            passwordErrors.push('Password must contain at least one uppercase letter');
        }
        if (!/[a-z]/.test(password)) {
            passwordErrors.push('Password must contain at least one lowercase letter');
        }
        if (!/\d/.test(password)) {
            passwordErrors.push('Password must contain at least one number');
        }
        if (!/[@$!%*?&]/.test(password)) {
            passwordErrors.push('Password must contain at least one special character (@, $, !, %, *, ?, &)');
        }
        
        return passwordErrors;
    };

    const handleNewPasswordChange = (e) => {
        const value = e.target.value;
        setNewPassword(value);
        setPasswordErrors(validatePassword(value)); // Validate the new password
    };

    const handlePasswordChange = async () => {
        if (newPassword !== confirmPassword) {
            alert("Passwords don't match. Please try again.");
            return;
        }

        if (passwordErrors.length > 0) {
            alert("Please correct the password errors before submitting.");
            return;
        }

        try {
            await axios.patch(`${baseUrl}/${userId}/update-password`, {
                currentPassword,
                newPassword
            });

            alert('Password changed successfully.');
            navigate('/auth');
        } catch (error) {
            console.error('Error changing password', error);
        }
    };


    return (
<div>
  {!isQuestionRetrieved ? (
    <div id="get-username">
      <input
        type="text"
        placeholder="Enter Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input type="button" value="Next" onClick={handleGetSecurityQuestion} />
    </div>
  ) : !isVerified ? (
    <div id="check-security-answer">
      <p>Security Question: {securityQuestion}</p>
      <input
        type="text"
        placeholder="Security Answer"
        value={securityAnswer}
        onChange={(e) => setSecurityAnswer(e.target.value)}
      />
      <input type="button" value="Check" onClick={handleCheckAnswer} />
      <p>Attempts remaining: {attempts}</p>
    </div>
  ) : (
    <div id="update-password">
      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={handleNewPasswordChange}
      />
      {passwordErrors.length > 0 && passwordErrors.map((error, index) => (
        <div key={index} className="error">{error}</div>
      ))}
      <input
        type="password"
        placeholder="Confirm New Password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
      />
      <input type="button" value="Submit" onClick={handlePasswordChange} />
    </div>
  )}
</div>
    );
};

export default ForgotPassword;