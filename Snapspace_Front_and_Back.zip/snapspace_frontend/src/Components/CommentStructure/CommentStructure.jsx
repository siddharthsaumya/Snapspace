import React from 'react';
import { baseUrl } from '../../Server';
import axios from 'axios';
import { timeDifferenceFromNow } from '../../Utils/DateTimeFunctions';
import '../CommentBox/Comment.css';

const CommentStructure = ({ comment, type, setNewComment, setParentCommentId, setIsEdit, userId, commentsList, setCommentsList }) => {

  const handleDeleteComment = async (commentId) => {
    try {
      await axios.delete(`${baseUrl}/${userId}/delete-comment/${commentId}`);
      setCommentsList(commentsList.filter(c => c.id !== commentId));
    } catch (error) {
      console.error("Error deleting comment:", error);
    }
  };
  return (
    <div className={`comment-structure-container ${type === 'reply' ? 'reply' : ''}`}>
    <div className='profile-section'>
      <img
        src={comment.user.profilePicture}
        className="profile-picture"
        alt="profile"
      />
      <span>{comment.user.username}</span>
    </div>

    <p>{comment.commentText}</p>
    <p>{timeDifferenceFromNow(comment.createdAt)}</p>
    {comment.user.id == userId && (
      <>
        <button onClick={() => { setNewComment(comment.commentText); setParentCommentId(comment.id); setIsEdit(true); }}>Edit</button>
        <button onClick={() => handleDeleteComment(comment.id)}>Delete</button>
      </>
    )}
  </div>
  
  );
};

export default CommentStructure;
