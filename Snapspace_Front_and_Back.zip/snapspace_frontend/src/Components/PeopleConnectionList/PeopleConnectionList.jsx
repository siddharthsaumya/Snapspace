import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Default_Pfp from '../../Assets/Default_Pfp.png';
import './PeopleConnectionList.css'

const PeopleConnectionList = ({pcList, pcListType, userInfo, setPcListOpen}) => {
  const navigate = useNavigate();  

  return (
  <div className='connection-list'>
      <button className='close-btn' onClick={() => setPcListOpen(false)}>Close</button>
      {pcListType == 'FOLLOWER' ? <div className='heading'>Followers List</div> : <div className='heading'>Following List</div>}
      <div className='users-container'>
      
      {pcList.length > 0 ? (
        pcList.map((user) => (
        <div className='user-container' onClick={() => navigate('/profile/' + userInfo.id + '/' + user.id)}>
            <img
              src={user.profilePicture || Default_Pfp}
              className="profile-picture"
              alt="profile"
            />
            <div className="user-info">
              <div className="username">{user.username}</div>
              <div className="fullname">{user.fullName}</div>
            </div>
        </div>


        ))
      ) : (
        <p>{pcListType == 'FOLLOWER' ? 'No followers yet' : 'No following yet'}</p>
      )}
      </div>
    </div>
  );
};

export default PeopleConnectionList;
