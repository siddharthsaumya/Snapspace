import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Default_PFP from '../../Assets/Default_Pfp.png';
import { baseUrl } from '../../Server';
import { useNavigate, useLocation } from 'react-router-dom';
import './UpdateProfile.css';
import Available_Img from '../../Assets/available.png';
import Unavailable_Img from '../../Assets/unavailable.png';

const UpdateProfile = () => {
  const [userData, setUserData] = useState(() => {
    const savedUserData = localStorage.getItem('userData');
    return savedUserData ? JSON.parse(savedUserData) : null;
  });
  const [usernameExist, setUsernameExist] = useState(true);
  const [username, setUsername] = useState(userData?.username || '');
  const [selectedFile, setSelectedFile] = useState(null);
  const location = useLocation();

  const fetchUserData = async () => {
    const searchParams = new URLSearchParams(location.search);
    const myUid = searchParams.get('uid');

    await axios
      .get(`${baseUrl}/${myUid}/get-user-info`)
      .then((response) => {
        const userInformation = response.data.userDto;
        setUserData(userInformation);
        setUsername(userInformation.username);
        localStorage.setItem('userData', JSON.stringify(userInformation));
      })
      .catch((e) => {
        console.error("Cannot get user info:", e.response.data);
      });
  };

  useEffect(() => {
    if (!userData) {
      fetchUserData();
    }
  }, []);

  const handleUsernameChange = async (e) => {
    const value = e.target.value;
    setUsername(value);

    try {
      const response = await axios.get(`${baseUrl}/${value}/check-username-exists`);
      setUsernameExist(response.data.exists);
    } catch (e) {
      console.log('Error checking username:', e);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

const handleSubmit = async () => {
  if (usernameExist && username !== userData.username) {
    alert('Choose an available username');
    return;
  }

  const searchParams = new URLSearchParams(location.search);
  const myUid = searchParams.get('uid');

  let updatedPfpUrl = userData.profilePicture; // Use existing profile picture by default

  // If a new file is selected, upload it
  if (selectedFile) {
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const uploadResponse = await axios.post(`${baseUrl}/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      updatedPfpUrl = uploadResponse.data.url; // Use uploaded picture URL
    } catch (error) {
      console.error('There was an error uploading the file!', error);
      alert('Failed to upload profile picture');
      return; // Exit if picture upload fails
    }
  }

  // Now update the user information with the updated profile picture URL
  try {
    const response = await axios.put(
      `${baseUrl}/${myUid}/update-user-info`,
      {
        username: username,
        email: userData.email,
        fullName: userData.fullName,
        bio: userData.bio,
        profilePicture: updatedPfpUrl, // Ensure correct picture URL is sent
      },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (response.data.statusCode === 200) {
      alert('Profile updated successfully');
      localStorage.setItem('userData', JSON.stringify({ ...userData, username, profilePicture: updatedPfpUrl }));
      window.location.href = '/profile';
    }
  } catch (error) {
    console.error('Error updating user info:', error.response?.data || error);
    alert('Failed to update profile');
  }
};


  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  return (
    <div className="profile-update">
  <div className="profile-picture-container">
    <img
      className="profile-picture"
      src={userData?.profilePicture || Default_PFP}
      alt="Profile"
    />
    <label className="custom-file-upload">
      Upload Profile Picture
      <input type="file" onChange={handleFileChange} />
    </label>
  </div>

  <div className="input-container">
    <div className="input-field">
      <label>Username</label>
      <input
        name="username"
        value={username}
        autoComplete='off'
        className="username-input"
        onChange={handleUsernameChange}
      />
      <img
      className="username-status-icon"
      src={usernameExist ? Unavailable_Img : Available_Img}
      alt={usernameExist ? "Username Unavailable" : "Username Available"}
    />
    </div>

    <div className="input-field">
      <label>Email</label>
      <input
        name="email"
        value={userData?.email || ''}
        className="email-input"
        onChange={handleInputChange}
      />
    </div>

    <div className="input-field">
      <label>Full Name</label>
      <input
        name="fullName"
        value={userData?.fullName || ''}
        className="fullname-input"
        onChange={handleInputChange}
      />
    </div>

    <div className="input-field">
      <label>Bio</label>
      <input
        name="bio"
        value={userData?.bio || ''}
        className="bio-input"
        onChange={handleInputChange}
      />
    </div>

    <button className="update-button" onClick={handleSubmit}>Update Profile</button>
  </div>
</div>


  );
};

export default UpdateProfile;
