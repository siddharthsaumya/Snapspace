import React, { useState, useEffect } from 'react';
import CommentStructure from '../CommentStructure/CommentStructure';
import { baseUrl } from '../../Server';
import axios from 'axios';
import './Comment.css';

const CommentBox = ({ commentsList, setCommentsList, onClose, postId, userId, loadComments, isFollowed }) => {
  const [newComment, setNewComment] = useState('');
  const [isReply, setIsReply] = useState(false);
  const [parentCommentId, setParentCommentId] = useState(0);
  const [parentCommentText, setParentCommentText] = useState('');
  const [isEdit, setIsEdit] = useState(false);

  const handleAddComment = async () => {
    if (newComment.trim() === '') return;
    if (isEdit) {
      await axios.patch(`${baseUrl}/${userId}/edit-comment/${parentCommentId}`, { newCommentText: newComment }, {
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(response => {
        alert("Comment Edited");
        console.log(response);
      })
      .catch(error => {
        console.error(error);
      });

      setIsEdit(false);
    } else {
      var url = '';
      if (isReply) url = '/add-reply';
      else url = '/add-comment';
      await axios.post(baseUrl + url, {
        "postId": postId,
        "userId": userId,
        "commentText": newComment,
        "parentCommentId": parentCommentId
      });
      alert("Comment Posted");
    }
    setNewComment('');
    loadComments();
  };

  const handleReplySelection = (commentId, commentText) => {
    setParentCommentId(commentId);
    setParentCommentText(commentText);
    setIsReply(true);
  };

  const handleCancelReply = () => {
    setIsReply(false);
    setParentCommentId(0);
    setParentCommentText('');
  };

  return (
    <div className='comment-container'>
      <span className='comment-header'>Comments</span>
      {commentsList.map((comment) => (
        <div className='comments-list' key={comment.id}>
          <CommentStructure
            comment={comment}
            type={'comment'}
            setNewComment={setNewComment}
            setIsEdit={setIsEdit}
            userId={userId}
            setParentCommentId={setParentCommentId}
            commentsList={commentsList}
            setCommentsList={setCommentsList} // Passing the state function
          />
          <button className='reply-btn' onClick={() => handleReplySelection(comment.id, comment.commentText)}>Reply</button>
          {comment.replies.length > 0 &&
            comment.replies.map((reply) => (
              <CommentStructure
                key={reply.id}
                comment={reply}
                type={'reply'}
                setNewComment={setNewComment}
                userId={userId}
                setIsEdit={setIsEdit}
                setParentCommentId={setParentCommentId}
                commentsList={commentsList}
                setCommentsList={setCommentsList}
              />
            ))}
        </div>
      ))}

      <div className='input-container'>
        {isReply && (
          <div className='reply-highlight-container'>
            <span>{`Replying to: ${parentCommentText}`}</span>
            <button onClick={handleCancelReply} style={{ marginLeft: 'auto', backgroundColor: 'transparent', border: 'none', color: 'red', cursor: 'pointer', fontWeight: 'bold' }}>
              ✕
            </button>
          </div>
        )}
        {isFollowed &&
          <div className='input-holder'>
            <input
              type="text"
              value={newComment}
              className='input-box'
              onChange={(e) => setNewComment(e.target.value)}
              placeholder={isReply ? "Write a reply..." : "Write a comment..."}
            />
            <button
              className='post-btn'
              onClick={() => handleAddComment()}>
              {isReply ? "Reply" : "Comment"}
            </button>
          </div>
        }
      </div>
    </div>
  );
};

export default CommentBox;
