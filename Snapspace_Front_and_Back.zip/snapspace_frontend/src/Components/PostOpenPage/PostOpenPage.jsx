import React, { useState, useEffect } from 'react';
import Post from '../Post/Post';
import { useParams } from "react-router-dom";
import { baseUrl } from '../../Server';
import axios from 'axios';

const PostOpenPage = () => {
    let { postid, userid } = useParams();
    const [postInfo, setPostInfo] = useState(null);

    useEffect(() => {
        axios.get(`${baseUrl}/${userid}/get-post/${postid}`)
        .then(response => {
            setPostInfo(response.data.post);
        })
        .catch(e => {
          console.error("Cannot get post data:", e);
        });
      }, [postid, userid]);

    if (!postInfo) {
        return <div>Loading...</div>;
    }

    return (
        <Post className='post' userId={userid} postInfo={postInfo}/>
    );
};

export default PostOpenPage;
