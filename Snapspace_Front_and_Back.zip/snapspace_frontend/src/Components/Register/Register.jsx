import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CookiesService from '../../Services/CookiesService';
import { baseUrl } from '../../Server';
import './Register.css';

function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [fullName, setFullName] = useState('');
    const [securityQuestionId, setSecurityQuestionId] = useState('');
    const [securityAnswer, setSecurityAnswer] = useState('');
    const [questionsList, setQuestionsList] = useState([]);
    
    const [errors, setErrors] = useState({
        username: '',
        password: [],
        email: '',
        fullName: '',
        securityQuestionId: '',
        securityAnswer: '',
    });


    const fetchQuestions = () => {
        axios.get(`${baseUrl}/get-all-questions`)
          .then(response => {
            setQuestionsList(response.data.questions);
          })
          .catch(e => {
            console.error("Cannot get questions list API:", e.response.data);
          });
      }
      useEffect(() => {
        fetchQuestions();
      }, []);

      
    // Validation functions
    const validateUsername = (username) => {
        if (!username) {
            return 'Username is required';
        } else if (username.length > 50) {
            return 'Username too long';
        } else if (!/^[a-zA-Z0-9._]+$/.test(username)) {
            return 'Username can only contain letters, numbers, ., and _';
        }
        return '';
    };

    const validatePassword = (password) => {
        const passwordErrors = [];
        
        if (!password) {
            passwordErrors.push('Password is required');
        }
        if (password.length < 8) {
            passwordErrors.push('Password must be at least 8 characters long');
        }
        if (!/[A-Z]/.test(password)) {
            passwordErrors.push('Password must contain at least one uppercase letter');
        }
        if (!/[a-z]/.test(password)) {
            passwordErrors.push('Password must contain at least one lowercase letter');
        }
        if (!/\d/.test(password)) {
            passwordErrors.push('Password must contain at least one number');
        }
        if (!/[@$!%*?&]/.test(password)) {
            passwordErrors.push('Password must contain at least one special character (@, $, !, %, *, ?, &)');
        }
        
        return passwordErrors;
    };

    const validateEmail = (email) => {
        if (!email) {
            return 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            return 'Invalid email address';
        }
        return '';
    };

    const validateFullName = (fullName) => {
        if (!fullName) {
            return 'Full Name is required';
        }
        return '';
    };

    const validateSecurityQuestionId = (securityQuestionId) => {
        if (!securityQuestionId) {
            return 'Please select a security question';
        }
        return '';
    };

    const validateSecurityAnswer = (securityAnswer) => {
        if (!securityAnswer) {
            return 'Security answer is required';
        }
        return '';
    };

    // Input change handlers with live validation
    const handleUsernameChange = (e) => {
        const value = e.target.value;
        setUsername(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            username: validateUsername(value),
        }));
    };

    const handlePasswordChange = (e) => {
        const value = e.target.value;
        setPassword(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            password: validatePassword(value),
        }));
    };

    const handleEmailChange = (e) => {
        const value = e.target.value;
        setEmail(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            email: validateEmail(value),
        }));
    };

    const handleFullNameChange = (e) => {
        const value = e.target.value;
        setFullName(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            fullName: validateFullName(value),
        }));
    };

    const handleSecurityQuestionChange = (e) => {
        const value = e.target.value;
        setSecurityQuestionId(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            securityQuestionId: validateSecurityQuestionId(value),
        }));
    };

    const handleSecurityAnswerChange = (e) => {
        const value = e.target.value;
        setSecurityAnswer(value);
        setErrors((prevErrors) => ({
            ...prevErrors,
            securityAnswer: validateSecurityAnswer(value),
        }));
    };

    const handleRegister = async (e) => {
        e.preventDefault();

        // Perform a final validation check before submission
        const newErrors = {
            username: validateUsername(username),
            password: validatePassword(password),
            email: validateEmail(email),
            fullName: validateFullName(fullName),
            securityQuestionId: validateSecurityQuestionId(securityQuestionId),
            securityAnswer: validateSecurityAnswer(securityAnswer),
        };

        setErrors(newErrors);
        if (Object.values(newErrors).some((error) => error.length > 0)) {
            return;
        }

        const userData = {
            username,
            password,
            email,
            fullName,
            securityQuestionId: Number(securityQuestionId),
            securityAnswer,
        };

        try {
            const response = await axios.post(baseUrl + '/register', userData);
            console.log('Registration successful:', response.data.token);
            alert('Registration successful');
            CookiesService.setToken(response.data.token, response.data.expiration);
            window.location.href = "/";
        } catch (error) {
            const statusCode = error.response?.data?.statusCode || 0;
            if (statusCode === 403) {
                alert('User already exists');
                console.log("USER ALREADY EXISTS");
            } else if (statusCode === 1002) {
                alert('Invalid input data');
                console.log("INVALID INPUT DATA");
            } else {
                alert('An unexpected error occurred');
                console.log("An unexpected error occurred:", error);
            }
        }
    };

    return (
<div className="register-container">
  <h2 className="register-heading">Register</h2>
  <form className="register-form" onSubmit={handleRegister}>
    <div className="input-container">
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={handleUsernameChange}
        className="input-field"
        required
      />
      {errors.username && <div className="error">{errors.username}</div>}
    </div>
    <div className="input-container">
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={handlePasswordChange}
        className="input-field"
        required
      />
      {errors.password.length > 0 &&
        errors.password.map((error, index) => (
          <div key={index} className="error">{error}</div>
        ))}
    </div>
    <div className="input-container">
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={handleEmailChange}
        className="input-field"
        required
      />
      {errors.email && <div className="error">{errors.email}</div>}
    </div>
    <div className="input-container">
      <input
        type="text"
        placeholder="Full Name"
        value={fullName}
        onChange={handleFullNameChange}
        className="input-field"
        required
      />
      {errors.fullName && <div className="error">{errors.fullName}</div>}
    </div>
    <div className="input-container">
      <select
        value={securityQuestionId}
        onChange={handleSecurityQuestionChange}
        className="input-field"
        required
      >
        <option value="" disabled>Select Security Question</option>
        {questionsList.map((ques, index) => (
            <option key={index} value={ques.id}>{ques.question}</option>
            ))}
      </select>
      {errors.securityQuestionId && <div className="error">{errors.securityQuestionId}</div>}
    </div>
    <div className="input-container">
      <input
        type="text"
        placeholder="Security Answer"
        value={securityAnswer}
        onChange={handleSecurityAnswerChange}
        className="input-field"
        required
      />
      {errors.securityAnswer && <div className="error">{errors.securityAnswer}</div>}
    </div>
    <button type="submit" className="register-button">
      Register
    </button>
  </form>
</div>
    );
}

export default Register;
