import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SearchBar.css';

const SearchBar = () => {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();  

  const handleChange = (e) => {
    const newQuery = e.target.value;
    setQuery(newQuery);
    if (newQuery.length > 0) {
      navigate(`/search?query=${newQuery}`);
    } else {
      navigate(`/`);
    }
  };

  return (
    <div className='searchbar-container'>
      <input 
        type="text" 
        value={query} 
        onChange={handleChange}
        autoComplete="off" 
        placeholder="Search..." 
        name="searchBar"
        id="searchBar"
        className='searchbar'
      />
    </div>
  );
};

export default SearchBar;
