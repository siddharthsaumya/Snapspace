import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import './OnlineStatusToggle.css';

const OnlineStatusToggle = ({ userInfo, onColor }) => {
  const [userData, setUserData] = useState(null);
  const [isOn, setIsOn] = useState(userInfo?.onlineStatus || true);

  useEffect(() => {
    if (userInfo) {
      setUserData(userInfo);
      setIsOn(userInfo.onlineStatus);
    }
  }, [userInfo]);

  const handleToggle = async () => {
    try {
      await axios.patch(`${baseUrl}/${userData.id}/toggle-online-status`);
      setIsOn(!isOn);
    } catch (error) {
      console.error('Error toggling online status', error.response);
    }
  };

  if (!userData || !userData.id) {
    return null; // Return null if userData is not available to avoid rendering the component
  }

  return (
<div className="toggle-switch">
  <span className="label offline">Offline</span>
  <input
    className="toggle-checkbox"
    id={`toggle-switch`}
    type="checkbox"
    checked={isOn}
    onChange={handleToggle}
  />
  <label
    className="toggle-label"
    htmlFor={`toggle-switch`}
    style={{ background: isOn ? onColor : '#ccc' }}
  >
    <span className={`toggle-button`} />
  </label>
  <span className="label online">Online</span>
</div>



  );
};

export default OnlineStatusToggle;
