import React, { useState, useRef, useEffect } from 'react';
import { useParams } from "react-router-dom";
import axios from 'axios';
import { baseUrl } from '../../Server';
import './OpenChatSection.css';
import Default_Pfp from '../../Assets/Default_Pfp.png';
import Sent_Img from '../../Assets/sent.png';
import Read_Img from '../../Assets/read.png';
import Delete_Img from '../../Assets/delete.png';

const OpenChatSection = ({ pfp, username, myUserId, targetUserId, messageList, onlineStatus, LoadMessages }) => {
    const [hoveredMessageId, setHoveredMessageId] = useState(null);
    const messageEndRef = useRef(null);

    const scrollToBottom = () => {
        messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    const handleSendMessage = async () => {
        const messageText = document.getElementById('messageInputBox').value;

        const response = await axios.post(baseUrl + '/send-message', {
            "senderId": myUserId,
            "recipientId": targetUserId,
            "messageText": messageText
        });
        document.getElementById('messageInputBox').value = '';
        LoadMessages();
        scrollToBottom();
    }

    const handleDeleteMessage = async (messageId) => {
        try {
        await axios.delete(baseUrl+'/'+myUserId+'/delete-message/'+messageId);
        LoadMessages();
        } catch (error) {
            console.error(error);
        }
        
    };

    return (
        <div className='open-chat-section'>
            <div className='chat-info'>
            <img
                src={pfp || Default_Pfp}
                className="profile-picture"
            />
            <div className='username'>{username}</div>
            {onlineStatus ? <div className='online-status online' >Online</div> : <div className='online-status offline'>Offline</div> }
            </div>
 <div className='messages-container'>
            {messageList
                .slice()
                .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
                .map(chat => (
                    <div 
                        key={chat.id}
                        className='msg-container'
                        onMouseEnter={() => setHoveredMessageId(chat.id)}
                        onMouseLeave={() => setHoveredMessageId(null)}
                    >
                        <p
    className={`msg-text ${chat.senderId === myUserId ? 'my-message' : 'other-message'}`}
>
    {hoveredMessageId === chat.id && chat.senderId === myUserId && (
        <img className='delete-msg' src={Delete_Img} onClick={() => handleDeleteMessage(chat.id)} />
    )}
    {chat.messageText} 
    {chat.senderId === myUserId ? chat.readStatus ? <img src={Read_Img} className='read-status' /> : <img src={Sent_Img} className='read-status' /> : ''}
</p>

                    </div>
                ))}
                </div>
                <div ref={messageEndRef} />
        <div className='input-container'>
        <input id='messageInputBox' placeholder='Write message here...' className='msg-input' type='text' />
        <button className='send-msg-btn' onClick={handleSendMessage}>Send</button>
        </div>
             </div>
    );
};

export default OpenChatSection;
