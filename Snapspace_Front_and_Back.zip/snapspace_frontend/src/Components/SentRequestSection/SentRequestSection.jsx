import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import {timeDifferenceFromNowFull} from '../../Utils/DateTimeFunctions';
import {getNotificationMessage} from '../../Utils/NotificationText';
import CookiesService from '../../Services/CookiesService';
import './SentRequestSection.css';

const SentRequestSection = ({ userInfo }) => {
    const [sentRequestList, setSentRequestList] = useState([]);

  useEffect(() => {
    axios.get(`${baseUrl}/${userInfo.id}/get-pending-sent-requests`)
    .then(response => {
        setSentRequestList(response.data.followRequests);
    })
    .catch(e => {
        console.error(e);
    });
  }, []);

  return (
<div className="sent-requests-container">
  {sentRequestList.length > 0 ? (
    sentRequestList.map((requests) => (
      <a key={requests.id} href={'/profile/' + userInfo.id + '/' + requests.userId} className="request-item">
        <img
          src={requests.profilePicture}
          className="profile-picture"
          alt="profile"
        />
        <span className="request-info">
          Your follow request to {requests.fullName} (<b>{requests.username}</b>) is pending since <b>{timeDifferenceFromNowFull(requests.createdAt)}</b>
        </span>
      </a>
    ))
  ) : (
    <p className="no-requests-message">No Pending Requests Found</p>
  )}
</div>

  );
};

export default SentRequestSection;
