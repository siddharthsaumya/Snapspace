import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { baseUrl } from '../../Server';
import './UpdatePassword.css';

const UpdatePassword = ({ userInfo, handleLogout }) => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordErrors, setPasswordErrors] = useState([]);
    const [userData, setUserData] = useState(null);
    const [logoutAfterChange, setLogoutAfterChange] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        setUserData(userInfo);
    }, [userInfo]);

    const validatePassword = (password) => {
        const errors = [];

        if (!password) {
            errors.push('Password is required');
        }
        if (password.length < 8) {
            errors.push('Password must be at least 8 characters long');
        }
        if (!/[A-Z]/.test(password)) {
            errors.push('Password must contain at least one uppercase letter');
        }
        if (!/[a-z]/.test(password)) {
            errors.push('Password must contain at least one lowercase letter');
        }
        if (!/\d/.test(password)) {
            errors.push('Password must contain at least one number');
        }
        if (!/[@$!%*?&]/.test(password)) {
            errors.push('Password must contain at least one special character (@, $, !, %, *, ?, &)');
        }

        return errors;
    };

    const handleNewPasswordChange = (e) => {
        const value = e.target.value;
        setNewPassword(value);
        setPasswordErrors(validatePassword(value));
    };

    const handlePasswordChange = async () => {
        if (newPassword !== confirmPassword) {
            alert("Passwords don't match. Please try again.");
            return;
        }

        if (passwordErrors.length > 0) {
            alert("Please correct the password errors before submitting.");
            return;
        }

        try {
            await axios.patch(`${baseUrl}/${userData.id}/update-password`, {
                currentPassword,
                newPassword
            });

            alert('Password changed successfully.');

            if (logoutAfterChange) {
                handleLogout();
            } else {
                navigate('/profile');
            }
        } catch (error) {
            if (error.response.data.statusCode == 1001) alert("Wrong current password");
            else console.error('Error changing password', error.response);
        }
    };

    return (
<div className="update-password-container">
  <div id="update-password" className="update-password-form">
    <input
      type="password"
      placeholder="Current Password"
      value={currentPassword}
      onChange={(e) => setCurrentPassword(e.target.value)}
      className="password-input"
    />
    <input
      type="password"
      placeholder="New Password"
      value={newPassword}
      onChange={handleNewPasswordChange}
      className="password-input"
    />
    {passwordErrors.length > 0 && passwordErrors.map((error, index) => (
      <div key={index} className="error">{error}</div>
    ))}
    <input
      type="password"
      placeholder="Confirm New Password"
      value={confirmPassword}
      onChange={(e) => setConfirmPassword(e.target.value)}
      className="password-input"
    />

    <div className="logout-checkbox-container">
      <input
        type="checkbox"
        id="logoutAfterChange"
        checked={logoutAfterChange}
        onChange={(e) => setLogoutAfterChange(e.target.checked)}
        className="logout-checkbox"
      />
      <label htmlFor="logoutAfterChange">Log me out after changing the password</label>
    </div>

    <input type="button" value="Submit" onClick={handlePasswordChange} className="submit-button" />
  </div>
</div>
    );
};

export default UpdatePassword;
