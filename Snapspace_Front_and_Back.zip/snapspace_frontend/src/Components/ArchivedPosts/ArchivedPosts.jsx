import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../../Server';
import {timeDifferenceFromNow} from '../../Utils/DateTimeFunctions';
import {getNotificationMessage} from '../../Utils/NotificationText';
import CookiesService from '../../Services/CookiesService';
import Post from '../Post/Post';

const ArchivedPosts = ({ userInfo }) => {
    const [postsList, setPostsList] = useState([]);

  useEffect(() => {
    axios.get(`${baseUrl}/${userInfo.id}/get-archived-posts`)
    .then(response => {
        setPostsList(response.data.posts);
    })
    .catch(e => {
        if(e.response.data.statusCode == 404) setPostsList([]);
        else console.error(e.response.data);
    });
  }, []);

  return (
<div>
  {postsList.length > 0 ? (
    postsList.map((post, index) => (
      <Post className='post' key={index} userId={userInfo.id} postInfo={post} isPostArchived={true} />
    ))
  ) : (
    <p>No Archived Post Found</p>
  )}
</div>
  );
};

export default ArchivedPosts;
