import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import { baseUrl } from '../../Server';
import './ActionButtons.css';

const ActionButtons = ({buttonType, ownProfile, myUserId, targetId}) => {

    const [chatId, setChatId] = useState(null);
    const [pfp, setPfp] = useState(null);
    const [username, setUsername] = useState(null);
    const [currentButtonType, setCurrentButtonType] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
      setCurrentButtonType(buttonType);
        if (myUserId) {
          axios.get(`${baseUrl}/${myUserId}/get-chatId/${targetId}`)
            .then(response => {
              setChatId(response.data.chatId);
              setPfp(response.data.userProfilePicture);
              setUsername(response.data.username);
            })
            .catch(e => {
              console.error("Cannot get chatid info:", e.response.data);
            });
        }
      }, [myUserId, targetId]);

      const followUser = () => {
        axios.post(`${baseUrl}/follow-user`,{"userId": myUserId, "followUserId": targetId})
            .then(response => {
              setCurrentButtonType('REQ-SENT');
            })
            .catch(e => {
              console.error("Cannot unfollow user:", e.response.data);
            });
      }

      const unfollowUser = () => {
        axios.delete(`${baseUrl}/${myUserId}/unfollow-user/${targetId}`)
            .then(response => {
              setCurrentButtonType('NOT-FOLLOW');
            })
            .catch(e => {
              console.error("Cannot unfollow user:", e.response.data);
            });
      }

      const cancelFollowRequest = () => {
        axios.delete(`${baseUrl}/${myUserId}/cancel-follow-request/${targetId}`)
            .then(response => {
              setCurrentButtonType('NOT-FOLLOW');
            })
            .catch(e => {
              console.error("Cannot unfollow user:", e.response.data);
            });
      }

      const handleMessage = () => {
        navigate('/chats?cid='+chatId+'&pfp='+pfp+'&username='+username+'&tid='+targetId);
      }

    return (
        <div className='action-buttons'>
            {ownProfile == true ? 
            <button onClick={() => navigate('/update-profile?uid='+targetId)}>EDIT PROFILE</button> 
            : 
            (currentButtonType == 'REQ-SENT'?
            <div><button onClick={cancelFollowRequest}>CANCEL REQUEST</button><button onClick={handleMessage}>MESSAGE</button> </div>
            : 
            (currentButtonType == 'FOLLOW'?
            <div><button onClick={unfollowUser}>UNFOLLOW</button><button onClick={handleMessage}>MESSAGE</button></div>
            :
            (currentButtonType == 'NOT-FOLLOW'?
            <div><button onClick={followUser}>FOLLOW</button><button onClick={handleMessage}>MESSAGE</button></div>:<button disabled>NOT AVAILABLE</button>)))}
        </div>
        
      );
    };
    
export default ActionButtons;
    