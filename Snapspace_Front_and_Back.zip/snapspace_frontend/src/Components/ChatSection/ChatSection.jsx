import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';
import { baseUrl } from '../../Server';
import { timeDifferenceFromNow } from '../../Utils/DateTimeFunctions';
import OpenChatSection from '../OpenChatSection/OpenChatSection';
import './ChatSection.css';
import Delete_Img from '../../Assets/delete.png';
import SliceTextMsgPreview from '../../Utils/SliceTextMsgPreview';

const ChatSection = ({ userInfo }) => {
  const [userData, setUserData] = useState(null);
  const [chatList, setChatList] = useState([]);
  const [messageList, setMessageList] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [messagePfp, setMessagePfp] = useState(null);
  const [selectedUsername, setSelectedUsername] = useState(null);
  const [targetUserId, setTargetUserId] = useState(null);
  const [onlineStatus, setOnlineStatus] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const LoadMessages = () => {
    if (userData && selectedChat) {
      axios.get(`${baseUrl}/${userData.id}/get-messages/${selectedChat}`)
        .then(response => {
          setMessageList(response.data.messages);
        })
        .catch(e => {
          console.error("Cannot get message list api:", e.response.data);
        });
    }
  };

  const LoadChats = () => {
    axios.get(`${baseUrl}/${userData.id}/get-chats`)
        .then(response => {
          setChatList(response.data.chats);
        })
        .catch(e => {
          console.error("Cannot get chat list api:", e.response.data);
        });
  }

  useEffect(() => {
    setUserData(userInfo);
    const searchParams = new URLSearchParams(location.search);
    setSelectedChat(searchParams.get('cid'));
    setMessagePfp(searchParams.get('pfp'));
    setSelectedUsername(searchParams.get('username'));
    setTargetUserId(searchParams.get('tid'));
  }, [userInfo, location.search]);

  useEffect(() => {
    if (userData) {
      LoadChats();

      const MessageListLoad = setInterval(() => {
        LoadMessages();
      }, 2000);

      const OnlineStatusRefreshInterval = setInterval(() => {
        if (targetUserId) {
          axios.get(`${baseUrl}/${targetUserId}/get-online-status`)
            .then(response => {
              setOnlineStatus(response.data.status);
            })
            .catch(e => {
              console.error("Cannot get online status api:", e.response.data);
            });
        }
      }, 5000);

      return () => {
        clearInterval(OnlineStatusRefreshInterval);
        clearInterval(MessageListLoad);
      };
    }
  }, [userData, selectedChat, targetUserId]);

  const handleSelectedChat = (chat, pfp, username, targetUserId) => {
    setSelectedChat(chat.chatId);
    setMessagePfp(pfp);
    setSelectedUsername(username);
    setTargetUserId(targetUserId);
  };

  const handleDeleteChat = async (chatId) => {
    try {
      await axios.delete(baseUrl+'/'+userData.id+'/delete-chat/'+chatId);
      LoadChats();
      setSelectedChat(null);
      } catch (error) {
          console.error(error);
      }
  }

  return (
    <div className='chat-section'>
      <div className='chat-list'>
        {chatList.length > 0 ? (
          chatList.map(chat => (
            <div key={chat.chatId}>
              {chat.participants
                .filter(participant => participant.id !== (userData && userData.id))
                .map(participant => (
                  <div
                    key={participant.id}
                    onClick={() => handleSelectedChat(chat, participant.profilePicture, participant.username, participant.id)}
                    className="participant chat-item"
                  >
                    <img
                      src={participant.profilePicture}
                      alt={participant.username}
                      className="profile-picture"
                    />
                    <span>
                    <div className='username'>{participant.username}</div>
                    <div className="chat-details">
                      {SliceTextMsgPreview(chat.latestMessage)}  ({timeDifferenceFromNow(chat.latestMessageTime)})
                    </div>
                    </span>
                    {chat.unreadMessageCount > 0 && <div className='unread-msg-count'>{chat.unreadMessageCount}</div>}
                      <img src={Delete_Img} className='delete-chat' onClick={() => handleDeleteChat(chat.chatId)}/>

                  </div>
                ))}
            </div>
          ))
        ) : (
          <p className='no-chat'>No chats here yet</p>
        )}
      </div>

      <div className='selected-chat'>
        {selectedChat === null ?
          <div className='blank-chat'>Select A Chat</div>
          :
          <OpenChatSection
            pfp={messagePfp}
            username={selectedUsername}
            myUserId={userData ? userData.id : null}
            targetUserId={targetUserId}
            messageList={messageList}
            onlineStatus={onlineStatus}
            LoadMessages={LoadMessages}
          />
        }
      </div>
    </div>
  );
};

export default ChatSection;
