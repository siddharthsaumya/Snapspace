import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { baseUrl } from '../../Server';
import axios from 'axios';
import './SearchSection.css';

const SearchSection = ({ userInfo }) => {
  const [usersList, setUsersList] = useState([]);
  const [userData, setUserData] = useState(null);

  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const query = searchParams.get('query');

  useEffect(() => {
    setUserData(userInfo);
  }, [userInfo]);

  useEffect(() => {
    const searchUsers = async () => {
      if (!query){
        navigate(`/`)
    }else{
        try {
            const response = await axios.post(`${baseUrl}/${userData.id}/search`, {
              searchTerm: query,
            });
    
            if (response.status === 200) {
              setUsersList(response.data.users); 
            } else {
              console.error('Error: Received non-200 response:', response);
              setUsersList([]);
            }
          } catch (error) {
            console.error('Error searching users:', error);
            setUsersList([]);
          }
    }
    };

    searchUsers();
  }, [query, userData]);

  return (
<div className="user-list-container">
  {usersList.length > 0 ? (
    usersList.map((user) => (
      <a
        key={user.id}
        href={`/profile/${userData.id}/${user.id}`}
        className="user-list-item"
      >
        <img
          src={user.profilePicture}
          className="profile-picture"
          alt="profile"
        />
        <span className="username">{user.fullName} ({user.username})</span>
      </a>
    ))
  ) : (
    <p className="no-users-message">No users found</p>
  )}
</div>
  );
};

export default SearchSection;
