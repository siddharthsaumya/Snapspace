import './App.css';
import CookiesService from './Services/CookiesService';
import { UserContext } from './Context/UserInfoContext';
import JWTDecoder from './Utils/JwtDecoder';
import { baseUrl } from '../src/Server';
import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Routes, useNavigate, Navigate } from 'react-router-dom';
import AuthPage from './Pages/AuthPage';
import PageNotFound from './Pages/PageNotFound';
import PostOpenPage from './Components/PostOpenPage/PostOpenPage';
import ChatSection from './Components/ChatSection/ChatSection';
import CreatePost from './Components/CreatePost/CreatePost';
import NotificationSection from './Components/NotificationSection/NotificationSection';
import ProfileSection from './Components/ProfileSection/ProfileSection';
import MainLayout from './Pages/MainLayout';
import Feed from './Components/Feed/Feed';
import UserProfileOpenPage from './Components/UserProfileOpenPage/UserProfileOpenPage';
import PostByTag from './Components/PostByTag/PostByTag';
import SettingSection from './Components/SettingSection/SettingSection';
import ForgotPassword from './Components/ForgotPassword/ForgotPassword';
import SearchSection from './Components/SearchSection/SearchSection';
import UpdateProfile from './Components/UpdateProfile/UpdateProfile';

function App() {
  const [userInfo, setUserInfo] = useState(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [unreadChatCount, setUnreadChatCount] = useState(0);

  const AutomaticLogout = async () => {
    localStorage.removeItem("userData");
    try {
    await axios.post(`${baseUrl}/${userInfo.id}/logout`);
    CookiesService.removeToken();
    window.location.href = '/';
    } catch (error) {
      console.error(error);
      window.location.href = '/';
    }
    
  };

  useEffect(() => {
    let interval;

    if (CookiesService.isAuthenticated()) {
      try {
        const token = CookiesService.getToken();
        const decodedToken = JWTDecoder(token);

        if (decodedToken && decodedToken.nameid) {
          axios.get(`${baseUrl}/${decodedToken.nameid}/get-user/${decodedToken.nameid}`)
            .then(response => {
              setUserInfo(response.data.userDto);
            })
            .catch(error => {
              console.error("Cannot get user info from API:", error.response ? error.response.data : error.message);
            });

          axios.get(`${baseUrl}/${decodedToken.nameid}/get-unread-notification-count`)
            .then(response => {
              setNotificationCount(response.data.unreadCount);
            })
            .catch(e => {
              console.error("Cannot get notification count from API:", e.response.data);
            });

          axios.get(`${baseUrl}/${decodedToken.nameid}/get-unread-chats-count`)
            .then(response => {
              setUnreadChatCount(response.data.count);
            })
            .catch(e => {
              console.error("Cannot get unread chat count from API:", e.response.data);
            });

          interval = setInterval(() => {
            const current_epoch = Math.floor(new Date().valueOf() / 1000);
            if (decodedToken.exp <= current_epoch-3) {
              AutomaticLogout(); 
            }
          }, 1000); 

        } else {
          console.error("Invalid token structure");
        }
      } catch (error) {
        console.error("Error decoding token:", error.message);
      }
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, []);

  return (
    <UserContext.Provider value={userInfo}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={CookiesService.isAuthenticated() ? <MainLayout userInfo={userInfo} notificationCount={notificationCount} unreadChatCount={unreadChatCount} /> : <Navigate to="/auth" />}>
            <Route index element={<Feed userInfo={userInfo} />} />
            <Route path="chats" element={<ChatSection userInfo={userInfo} />} />
            <Route path="create-post" element={<CreatePost userInfo={userInfo} />} />
            <Route path="notifications" element={<NotificationSection userInfo={userInfo} />} />
            <Route path="profile" element={<ProfileSection userInfo={userInfo} />} />
            <Route path="post/:userid/:postid" element={<PostOpenPage />} />
            <Route path="profile/:userid/:targetuserid" element={<UserProfileOpenPage userInfo={userInfo} />} />
            <Route path="tagged-posts/:userid/:tagname" element={<PostByTag userInfo={userInfo} />} />
            <Route path="setting" element={<SettingSection userInfo={userInfo} />} />
            <Route path="search" element={<SearchSection userInfo={userInfo} />} />
            <Route path="update-profile" element={<UpdateProfile userInfo={userInfo} />} />
          </Route>
          <Route path="/auth" element={CookiesService.isAuthenticated() ? <Navigate to="/" /> : <AuthPage />} />
          <Route path="/forgot-password" element={CookiesService.isAuthenticated() ? <Navigate to="/" /> : <ForgotPassword />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </BrowserRouter>
    </UserContext.Provider>
    
  );
}

export default App;
