import Cookies from 'js-cookie';
import {convertIsoToUtcString} from '../Utils/DateTimeFunctions';

const TOKEN_KEY = 'user_token';

const CookiesService = {

  // setToken(token) {
  //   Cookies.set(TOKEN_KEY, token);
  //   console.log("Cookie Stored",token);
  // },

  setToken(cvalue, exdays) {
    let expires = "expires="+convertIsoToUtcString(exdays);
    document.cookie = TOKEN_KEY + "=" + cvalue + ";" + expires + ";path=/";
  },


  getToken() {
    let name = TOKEN_KEY + "=";
    let ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  },


  removeToken() {
    Cookies.remove(TOKEN_KEY);
    console.log("Cookie removed");
  },

  isAuthenticated() {
    var checkauth = !!this.getToken();
    return checkauth;
  }
};

export default CookiesService;