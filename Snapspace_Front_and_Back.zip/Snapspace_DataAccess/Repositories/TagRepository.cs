﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class TagRepository : ITagRepository
    {
        private readonly SnapspaceDBContext _context;
        private readonly IPostRepository _postRepository;

        public TagRepository(SnapspaceDBContext context, IPostRepository postRepository)
        {
            _context = context;
            _postRepository = postRepository;
        }

        public async Task AddTags(int postId, List<string> tagNames)
        {
            Post post = await _postRepository.GetPostById(postId);

            await _context.Entry(post).Collection(p => p.Tags).LoadAsync();

            tagNames = tagNames.Distinct().ToList();

            foreach (string tagName in tagNames)
            {
                Tag existingTag = await _context.Tags.FirstOrDefaultAsync(t => t.TagName == tagName);

                if (existingTag == null)
                {
                    existingTag = new Tag
                    {
                        TagName = tagName
                    };

                    _context.Tags.Add(existingTag);
                }

                if (!post.Tags.Any(t => t.TagName == tagName))
                {
                    post.Tags.Add(existingTag);
                }
            }
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTagBindingsByPostId(int postId)
        {
            var post = await _context.Posts
                .Include(p => p.Tags)
                .FirstOrDefaultAsync(p => p.Id == postId);

            if (post != null)
            {
                post.Tags.Clear();
            }
            await _context.SaveChangesAsync();
        }


    }
}
