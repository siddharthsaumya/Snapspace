﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class LogRepository : ILogRepository
    {
        private readonly SnapspaceDBContext _context;

        public LogRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task CreateLog(int userId, Log log)
        {
            log.UserId = userId;
            log.CreatedAt = DateTime.Now;

            await _context.Logs.AddAsync(log);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Log>> GetLogsByUserId(int userId)
        {
            return await _context.Logs
                .Where(log => log.UserId == userId)
                .ToListAsync();
        }

    }
}
