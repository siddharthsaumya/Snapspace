﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly SnapspaceDBContext _context;

        public NotificationRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task AddNotification(int userId, int notificationType, int sourceId)
        {
            Notification notification = new Notification
            {
                UserId = userId,
                NotificationType = notificationType,
                SourceId = sourceId,
                CreatedAt = DateTime.Now,
                ReadStatus = false
            };

            _context.Notifications.Add(notification);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Notification>> GetNotificationsByUserId(int userId)
        {
            return await _context.Notifications
                .Where(n => n.UserId == userId)
                .ToListAsync();
        }

        public async Task MarkNotificationAsRead(int notificationId)
        {
            Notification notification = await _context.Notifications
                .FirstOrDefaultAsync(n => n.Id == notificationId);

            if (notification != null)
            {
                notification.ReadStatus = true;

                await _context.SaveChangesAsync();
            }
        }

        public async Task<int> GetUnreadNotificationCountByUserId(int userId)
        {
            return await _context.Notifications
                .Where(n => n.UserId == userId && n.ReadStatus == false)
                .CountAsync();
        }

        public async Task DeleteNotificationsForPost(int postId)
        {
            var notifications = await _context.Notifications
                .Where(n => (n.NotificationType == 3 || n.NotificationType == 4) && n.SourceId == postId)
                .ToListAsync();

            if (notifications.Any())
            {
                _context.Notifications.RemoveRange(notifications);
                await _context.SaveChangesAsync();
            }
        }

    }
}
