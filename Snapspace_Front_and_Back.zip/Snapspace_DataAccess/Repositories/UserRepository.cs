﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using Snapspace_DataAccess.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly SnapspaceDBContext _context;
        private readonly IChatRepository _chatRepository;

        public UserRepository(SnapspaceDBContext context, IChatRepository chatRepository)
        {
            _context = context;
            _chatRepository = chatRepository;
        }

        public async Task<IEnumerable<User>> GetAllUsers()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<User> GetUserById(int userId)
        {
            User user = await _context.Users
                .Include(u => u.FollowFollowers)
                .Include(u => u.FollowFollowings)
                .Include(u => u.Posts)
                .FirstOrDefaultAsync(u => u.Id == userId);

            return user;
        }

        public async Task<bool> IsFollowing(int userId, int targetUserId)
        {
            if (userId == targetUserId) return true;
            return await _context.Follows.AnyAsync(f => f.FollowerId == userId && f.FollowingId == targetUserId);
        }


        public async Task<int> GetFollowerCount(int userId)
        {
            return await _context.Follows.CountAsync(f => f.FollowingId == userId);
        }

        public async Task<int> GetFollowingCount(int userId)
        {
            return await _context.Follows.CountAsync(f => f.FollowerId == userId);
        }

        public async Task<int> GetPostCount(int userId)
        {
            return await _context.Posts.CountAsync(p => p.UserId == userId && p.Active == true);
        }
        public async Task<bool> UsernameExists(string username)
        {
            return await _context.Users.AnyAsync(u => u.Username == username);
        }
        public async Task<User> GetUserByUsername(string username)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        }

        public async Task<User> ValidateUser(string username, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Username == username && u.Password == password);
        }
        public async Task<bool> UserExists(string username, string email)
        {
            return await _context.Users.AnyAsync(u => u.Username == username || u.Email == email);
        }

        public async Task<User> CreateUser(User user)
        {
            try
            {
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
            }
            return user;
        }

        public async Task<bool> DeleteUser(int id, string password)
        {

            User user = await _context.Users
                .Include(u => u.Logs)
                .Include(u => u.Posts)
                .Include(u => u.Notifications)
                .Include(u => u.Likes)
                .Include(u => u.Comments)
                .Include(u => u.FollowRequestToUsers)
                .Include(u => u.FollowRequestFromUsers)
                .Include(u => u.FollowFollowings)
                .Include(u => u.FollowFollowers)
                .Include(u => u.Chats)
                .SingleOrDefaultAsync(u => u.Id == id && u.Password == HashFunctions.HashString(password));

            if (user == null)
            {
                return false;
            }

            _context.Logs.RemoveRange(user.Logs);
            _context.Posts.RemoveRange(user.Posts);
            _context.Notifications.RemoveRange(user.Notifications);
            _context.Likes.RemoveRange(user.Likes);
            _context.Comments.RemoveRange(user.Comments);
            _context.FollowRequests.RemoveRange(user.FollowRequestToUsers);
            _context.FollowRequests.RemoveRange(user.FollowRequestFromUsers);
            _context.Follows.RemoveRange(user.FollowFollowings);
            _context.Follows.RemoveRange(user.FollowFollowers);


            foreach (Chat chat in user.Chats)
            {
                chat.Users.Remove(user);
            }

            IQueryable<Message> messages = _context.Messages.Where(m => m.SenderId == id);
            _context.Messages.RemoveRange(messages);


            _context.Users.Remove(user);

            await _context.SaveChangesAsync();
            return true;
        }





        public async Task<bool> UpdatePassword(int userId, string newPassword)
        {
            User user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            user.Password = HashFunctions.HashString(newPassword);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DeactivateUser(int userId, string password)
        {
            User user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            User validateUser = await ValidateUser(user.Username, HashFunctions.HashString(password));
            if (validateUser == null)
            {
                return false;
            }

            user.Active = false;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ActivateUser(string username)
        {
            User user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
            {
                return false;
            }

            user.Active = true;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool?> GetUserOnlineStatus(int userId)
        {
            User user = await _context.Users.FindAsync(userId);
            return user?.OnlineStatus;
        }

        public async Task<bool> SetUserOnlineStatus(int userId, bool isOnline)
        {
            User user = await _context.Users.FindAsync(userId);

            if (user == null)
            {
                return false;
            }

            user.OnlineStatus = isOnline;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateUser(int userId, string username, string email, string fullName, string bio, string profilePicture)
        {
            User user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            user.Username = username;
            user.Email = email;
            user.FullName = fullName;
            user.Bio = bio;
            user.ProfilePicture = profilePicture;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<User>> SearchUsers(string searchTerm)
        {
            return await _context.Users
                .Where(u => u.FullName.Contains(searchTerm) || u.Username.Contains(searchTerm))
                .ToListAsync();
        }

        public async Task<int> GetUserIdByUsername(string username)
        {
            int user = await _context.Users
                .Where(u => u.Username == username)
                .Select(u => u.Id)
                .FirstOrDefaultAsync();

            return user;
        }

        public async Task<string?> GetSecurityQuestionByUsername(string username)
        {
            var user = await _context.Users
                .Where(u => u.Username == username)
                .Select(u => new { u.SecurityQuestionId })
                .FirstOrDefaultAsync();

            if (user == null || user.SecurityQuestionId == null)
            {
                return null;
            }

            var securityQuestion = await _context.SecurityQuestions
                .Where(q => q.Id == user.SecurityQuestionId)
                .Select(q => q.Question)
                .FirstOrDefaultAsync();

            return securityQuestion;
        }

    }
}
