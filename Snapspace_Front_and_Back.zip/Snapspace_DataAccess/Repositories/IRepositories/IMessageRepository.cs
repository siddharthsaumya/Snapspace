﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IMessageRepository
    {
        Task<Message> AddMessage(Message message);
        Task<Message> GetMessageById(int messageId);
        Task DeleteMessage(Message message);
        Task DeleteMessages(IEnumerable<Message> messages);
        Task<IEnumerable<Message>> GetMessagesByChatId(int chatId);
        Task UpdateMessagesReadStatus(int UserId, int chatId);
    }

}
