﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface ISecurityQuestionRepository
    {
        Task<List<SecurityQuestion>> GetSecurityQuestions();
        Task<bool> CreateSecurityQuestion(SecurityQuestion question);
        Task<(string Question, string Answer)?> GetSecurityQuestionAndAnswer(int userId);
        Task<bool> UpdateSecurityQuestionAndAnswer(int userId, int securityQuestionId, string securityAnswer);
    }
}
