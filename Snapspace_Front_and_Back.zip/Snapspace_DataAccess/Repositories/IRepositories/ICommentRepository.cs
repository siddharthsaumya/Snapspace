﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface ICommentRepository
    {
        int GetCommentCountByPostId(int postId);
        Task AddComment(Comment comment);
        Task<Comment> GetCommentById(int commentId);
        Task DeleteComment(Comment comment);
        Task<IEnumerable<Comment>> GetRepliesByParentId(int parentId);
        Task UpdateComment(Comment comment);
        Task<IEnumerable<Comment>> GetCommentsByPostId(int postId);
        Task DeleteCommentsByPostId(int postId);
    }
}
