﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IFollowRepository
    {
        Task<IEnumerable<User>> GetFollowingUsers(int userId);
        Task<IEnumerable<User>> GetFollowerUsers(int userId);
        Task<bool> UnfollowUser(int userId, int unfollowUserId);
        Task<IEnumerable<int>> GetFollowingUserIds(int userId);
        bool IsFollowing(int userId, int targetUserId);
    }

}
