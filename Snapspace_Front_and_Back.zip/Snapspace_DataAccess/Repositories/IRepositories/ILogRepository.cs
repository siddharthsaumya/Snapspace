﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface ILogRepository
    {
        Task CreateLog(int userId, Log log);
        Task<IEnumerable<Log>> GetLogsByUserId(int userId);
    }
}
