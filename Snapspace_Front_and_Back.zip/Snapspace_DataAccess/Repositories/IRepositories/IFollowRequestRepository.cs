﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IFollowRequestRepository
    {
        Task<IEnumerable<FollowRequest>> GetPendingFollowRequests(int userId);
        Task<IEnumerable<FollowRequest>> GetFollowRequestsSentByUser(int userId);
        Task<bool> DeleteFollowRequest(int userId, int removeFollowRequestId);
        Task<bool> CreateFollowRequest(FollowRequest followRequest);
        Task<bool> RejectFollowRequest(int followRequestId);
        Task<bool> AcceptFollowRequest(int followRequestId);
        Task<FollowRequest?> GetFollowRequestById(int id);
        bool HasPendingFollowRequest(int userId, int targetUserId);
    }

}
