﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IUserRepository
    {
        Task<IEnumerable<User>> GetAllUsers();
        Task<User> GetUserById(int id);
        Task<bool> IsFollowing(int userId, int targetUserId);
        Task<int> GetFollowerCount(int userId);
        Task<int> GetFollowingCount(int userId);
        Task<int> GetPostCount(int userId);
        Task<bool> UsernameExists(string username);
        Task<User> GetUserByUsername(string username);
        Task<User> ValidateUser(string username, string password);
        Task<bool> UserExists(string username, string email);
        Task<User> CreateUser(User user);
        Task<bool> DeleteUser(int id, string password);
        Task<bool> UpdatePassword(int userId, string newPassword);
        Task<bool> DeactivateUser(int userId, string password);
        Task<bool> ActivateUser(string username);
        Task<bool> UpdateUser(int userId, string username, string email, string fullName, string bio, string profilePicture);
        Task<IEnumerable<User>> SearchUsers(string searchTerm);
        Task<int> GetUserIdByUsername(string username);
        Task<bool?> GetUserOnlineStatus(int userId);
        Task<bool> SetUserOnlineStatus(int userId, bool isOnline);
        Task<string?> GetSecurityQuestionByUsername(string username);
    }
}
