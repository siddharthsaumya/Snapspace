﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IPostRepository
    {
        Task<Post> CreatePost(Post post);
        Task<Post> TogglePostActiveStatus(int postId);
        Task<IEnumerable<Post>> GetPostsByUserId(int userId, bool activeStatus);
        Task<Post> GetPostById(int postId);
        Task UpdatePost(Post post);
        Task<IEnumerable<Post>> GetPostsByUserIds(IEnumerable<int> userIds);
        Task<IEnumerable<Post>> GetPostsByTagName(string tagName);
        Task<int> GetUserIdByPostId(int postId);
        Task DeletePostById(int postId);
    }
}

