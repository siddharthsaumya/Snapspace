﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface INotificationRepository
    {
        Task AddNotification(int userId, int notificationType, int sourceId);
        Task<IEnumerable<Notification>> GetNotificationsByUserId(int userId);
        Task MarkNotificationAsRead(int notificationId);
        Task<int> GetUnreadNotificationCountByUserId(int userId);
        Task DeleteNotificationsForPost(int postId);
    }
}
