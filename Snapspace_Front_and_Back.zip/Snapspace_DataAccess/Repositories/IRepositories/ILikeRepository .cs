﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface ILikeRepository
    {
        int GetLikeCountByPostId(int postId);
        bool IsPostLikedByUser(int postId, int userId);
        Task AddLike(Like like);
        Task RemoveLike(int postId, int userId);
        Task DeleteLikesByPostId(int postId);
    }
}
