﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface ITagRepository
    {
        Task AddTags(int postId, List<string> tagNames);
        Task DeleteTagBindingsByPostId(int postId);
    }
}
