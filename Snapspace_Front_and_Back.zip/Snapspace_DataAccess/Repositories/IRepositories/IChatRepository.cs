﻿using Snapspace_DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories.IRepositories
{
    public interface IChatRepository
    {
        Task<Chat> GetChatByParticipants(int user1Id, int user2Id);
        Task<Chat> CreateChat(Chat chat);
        Task<Chat> GetChatById(int chatId);
        Task<IEnumerable<User>> GetChatParticipants(int chatId);
        Task DeleteChat(Chat chat);
        Task RemoveChatParticipants(Chat chat);
        Task<IEnumerable<Chat>> GetChatsByUserId(int userId);
        Task<Chat> GetChatWithUserDetails(int userId, int targetUserId);
    }

}
