﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class PostRepository : IPostRepository
    {
        private readonly SnapspaceDBContext _context;

        public PostRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task<Post> CreatePost(Post post)
        {
            _context.Posts.Add(post);
            await _context.SaveChangesAsync();
            return post;
        }

        public async Task<Post> TogglePostActiveStatus(int postId)
        {
            Post post = await _context.Posts.FindAsync(postId);

            if (post != null)
            {
                post.Active = !post.Active;
                await _context.SaveChangesAsync();
            }

            return post;
        }

        public async Task<IEnumerable<Post>> GetPostsByUserId(int userId, bool activeStatus)
        {
            return await _context.Posts.Where(p => p.UserId == userId && p.Active == activeStatus).ToListAsync();
        }

        public async Task<Post> GetPostById(int postId)
        {
            return await _context.Posts.FindAsync(postId);
        }

        public async Task UpdatePost(Post post)
        {
            _context.Posts.Update(post);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Post>> GetPostsByUserIds(IEnumerable<int> userIds)
        {
            return await _context.Posts
                .Where(p => userIds.Contains(p.UserId) && p.Active == true)
                .ToListAsync();
        }

        public async Task<IEnumerable<Post>> GetPostsByTagName(string tagName)
        {
            List<Post> posts = await _context.Posts
                .Where(p => p.Tags.Any(t => t.TagName == tagName))
                .ToListAsync();

            return posts;
        }
        public async Task<int> GetUserIdByPostId(int postId)
        {
            int userId = await _context.Posts
                .Where(p => p.Id == postId)
                .Select(p => p.UserId)
                .FirstOrDefaultAsync();

            return userId;
        }

        public async Task DeletePostById(int postId)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post != null)
            {
                _context.Posts.Remove(post);
            }
            await _context.SaveChangesAsync();
        }
    }
}
