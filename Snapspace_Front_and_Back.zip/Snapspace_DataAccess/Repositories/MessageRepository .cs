﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class MessageRepository : IMessageRepository
    {
        private readonly SnapspaceDBContext _context;

        public MessageRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task<Message> AddMessage(Message message)
        {
            _context.Messages.Add(message);
            await _context.SaveChangesAsync();
            return message;
        }

        public async Task<Message> GetMessageById(int messageId)
        {
            return await _context.Messages.FindAsync(messageId);
        }

        public async Task DeleteMessage(Message message)
        {
            _context.Messages.Remove(message);
            await _context.SaveChangesAsync();
        }
        public async Task<IEnumerable<Message>> GetMessagesByChatId(int chatId)
        {
            return await _context.Messages
                .Where(m => m.ChatId == chatId)
                .ToListAsync();
        }

        public async Task DeleteMessages(IEnumerable<Message> messages)
        {
            _context.Messages.RemoveRange(messages);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateMessagesReadStatus(int userId, int chatId)
        {
            List<Message> messages = await _context.Messages
                .Where(m => m.ChatId == chatId && m.ReadStatus == false && m.SenderId != userId)
                .ToListAsync();

            foreach (Message message in messages)
            {
                message.ReadStatus = true;
            }

            await _context.SaveChangesAsync();
        }
    }

}
