﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class SecurityQuestionRepository : ISecurityQuestionRepository
    {
        private readonly SnapspaceDBContext _context;

        public SecurityQuestionRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task<List<SecurityQuestion>> GetSecurityQuestions()
        {
            return await _context.SecurityQuestions.ToListAsync();
        }

        public async Task<bool> CreateSecurityQuestion(SecurityQuestion question)
        {
            _context.SecurityQuestions.Add(question);
            await _context.SaveChangesAsync();
            return true; 
        }

        public async Task<(string Question, string Answer)?> GetSecurityQuestionAndAnswer(int userId)
        {
            User user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return null;
            }

            SecurityQuestion securityQuestion = await _context.SecurityQuestions.FindAsync(user.SecurityQuestionId);
            if (securityQuestion == null)
            {
                return null;
            }

            return (securityQuestion.Question, user.SecurityAnswer);
        }

        public async Task<bool> UpdateSecurityQuestionAndAnswer(int userId, int securityQuestionId, string securityAnswer)
        {
            User user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return false;
            }

            user.SecurityQuestionId = securityQuestionId;
            user.SecurityAnswer = securityAnswer;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
