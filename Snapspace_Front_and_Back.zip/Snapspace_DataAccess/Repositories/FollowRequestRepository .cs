﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class FollowRequestRepository : IFollowRequestRepository
    {
        private readonly SnapspaceDBContext _context;

        public FollowRequestRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<FollowRequest>> GetPendingFollowRequests(int userId)
        {
            return await _context.FollowRequests
                .Where(fr => fr.ToUserId == userId && fr.Status == 0)
                .Include(fr => fr.FromUser)
                .ToListAsync();
        }

        public async Task<IEnumerable<FollowRequest>> GetFollowRequestsSentByUser(int userId)
        {
            return await _context.FollowRequests
                .Where(fr => fr.FromUserId == userId && fr.Status == 0)
                .Include(fr => fr.ToUser)
                .ToListAsync();
        }

        public async Task<bool> DeleteFollowRequest(int userId, int removeFollowRequestId)
        {
            if (_context.FollowRequests == null)
            {
                throw new InvalidOperationException("Database context is not properly initialized.");
            }

            FollowRequest followRequest = await _context.FollowRequests
                .FirstOrDefaultAsync(fr => fr.FromUserId == userId && fr.ToUserId == removeFollowRequestId && fr.Status == 0);

            if (followRequest == null)
            {
                return false;
            }

            _context.FollowRequests.Remove(followRequest);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> CreateFollowRequest(FollowRequest followRequest)
        {
            if (_context.FollowRequests == null)
            {
                throw new InvalidOperationException("Database context is not properly initialized.");
            }

            await _context.FollowRequests.AddAsync(followRequest);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> RejectFollowRequest(int followRequestId)
        {
            FollowRequest followRequest = await _context.FollowRequests.FindAsync(followRequestId);
            if (followRequest == null)
            {
                return false;
            }

            followRequest.Status = 2;
            _context.FollowRequests.Update(followRequest);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> AcceptFollowRequest(int followRequestId)
        {
            FollowRequest followRequest = await _context.FollowRequests.FindAsync(followRequestId);
            if (followRequest == null)
            {
                return false;
            }

            followRequest.Status = 1;
            _context.FollowRequests.Update(followRequest);

            Follow follow = new Follow
            {
                FollowerId = followRequest.FromUserId,
                FollowingId = followRequest.ToUserId,
                CreatedAt = DateTime.Now
            };
            _context.Follows.Add(follow);

            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<FollowRequest?> GetFollowRequestById(int id)
        {
            return await _context.FollowRequests
                .Include(fr => fr.FromUser)
                .Include(fr => fr.ToUser)
                .FirstOrDefaultAsync(fr => fr.Id == id);
        }

        public bool HasPendingFollowRequest(int userId, int targetUserId)
        {
            var followRequest = _context.FollowRequests
                .Any(fr => fr.FromUserId == targetUserId
                        && fr.ToUserId == userId
                        && fr.Status == 0); // Assuming '0' means pending

            return followRequest;
        }

    }

}
