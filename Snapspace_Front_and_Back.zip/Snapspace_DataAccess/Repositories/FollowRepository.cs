﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class FollowRepository : IFollowRepository
    {
        private readonly SnapspaceDBContext _context;

        public FollowRepository(SnapspaceDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<User>> GetFollowingUsers(int userId)
        {
            return await _context.Follows
                .Where(f => f.FollowerId == userId && f.FollowingId.HasValue)
                .Select(f => f.Following)
                .ToListAsync();
        }

        public async Task<IEnumerable<User>> GetFollowerUsers(int userId)
        {
            return await _context.Follows
                .Where(f => f.FollowingId == userId && f.FollowerId.HasValue)
                .Select(f => f.Follower)
                .ToListAsync();
        }

        public async Task<IEnumerable<int>> GetFollowingUserIds(int userId)
        {
            return await _context.Follows
                .Where(f => f.FollowerId == userId)
                .Select(f => f.FollowingId.Value)
                .ToListAsync();
        }


        public async Task<bool> UnfollowUser(int userId, int unfollowUserId)
        {
            if (_context.Follows == null || _context.FollowRequests == null)
            {
                throw new InvalidOperationException("Database context is not properly initialized.");
            }

            Follow follow = await _context.Follows
                .FirstOrDefaultAsync(f => f.FollowerId == userId && f.FollowingId == unfollowUserId);

            FollowRequest followRequest = await _context.FollowRequests
                .FirstOrDefaultAsync(fr => fr.FromUserId == userId && fr.ToUserId == unfollowUserId && fr.Status == 1);

            bool isRemoved = false;

            if (follow != null)
            {
                _context.Follows.Remove(follow);
                isRemoved = true;
            }

            if (followRequest != null)
            {
                _context.FollowRequests.Remove(followRequest);
                isRemoved = true;
            }

            if (isRemoved)
            {
                await _context.SaveChangesAsync();
            }

            return isRemoved;
        }

        public bool IsFollowing(int userId, int targetUserId)
        {
            var isFollowing = _context.Follows
                .Any(f => f.FollowerId == targetUserId && f.FollowingId == userId);

            return isFollowing;
        }

    }

}
