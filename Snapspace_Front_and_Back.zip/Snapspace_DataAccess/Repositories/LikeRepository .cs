﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class LikeRepository : ILikeRepository
    {
        private readonly SnapspaceDBContext _context;

        public LikeRepository(SnapspaceDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public int GetLikeCountByPostId(int postId)
        {
            return _context.Likes.Count(l => l.PostId == postId);
        }

        public bool IsPostLikedByUser(int postId, int userId)
        {
            var isLiked = (from like in _context.Likes
                           where like.PostId == postId && like.UserId == userId
                           select like).Any();

            return isLiked;
        }


        public async Task AddLike(Like like)
        {
            _context.Likes.Add(like);
            await _context.SaveChangesAsync();
        }

        public async Task RemoveLike(int postId, int userId)
        {
            Like like = await _context.Likes.FirstOrDefaultAsync(l => l.PostId == postId && l.UserId == userId);
            if (like != null)
            {
                _context.Likes.Remove(like);
                await _context.SaveChangesAsync();
            }
        }

        public async Task DeleteLikesByPostId(int postId)
        {
            var likes = await _context.Likes
                .Where(l => l.PostId == postId)
                .ToListAsync();

            if (likes.Any())
            {
                _context.Likes.RemoveRange(likes);
            }
            await _context.SaveChangesAsync();
        }


    }
}
