﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class ChatRepository : IChatRepository
    {
        private readonly SnapspaceDBContext _context;

        public ChatRepository(SnapspaceDBContext context)
        {
            _context = context;
        }

        public async Task<Chat> GetChatByParticipants(int user1Id, int user2Id)
        {
            return await _context.Chats
                .Include(c => c.Users)
                .FirstOrDefaultAsync(c => c.Users.Any(u => u.Id == user1Id) &&
                                          c.Users.Any(u => u.Id == user2Id));
        }

        public async Task<Chat> CreateChat(Chat chat)
        {
            _context.Chats.Add(chat);
            await _context.SaveChangesAsync();
            return chat;
        }

        public async Task<Chat> GetChatById(int chatId)
        {
            return await _context.Chats
                .Include(c => c.Users) 
                .FirstOrDefaultAsync(c => c.Id == chatId);
        }



        public async Task<IEnumerable<User>> GetChatParticipants(int chatId)
        {
            Chat chat = await _context.Chats
                .Include(c => c.Users)
                .FirstOrDefaultAsync(c => c.Id == chatId);
            return chat?.Users ?? new List<User>();
        }

        public async Task DeleteChat(Chat chat)
        {
            _context.Chats.Remove(chat);
            await _context.SaveChangesAsync();
        }

        public async Task RemoveChatParticipants(Chat chat)
        {
            chat.Users.Clear();
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Chat>> GetChatsByUserId(int userId)
        {
            return await _context.Chats
                .Include(c => c.Users)
                .Include(c => c.Messages)
                .Where(c => c.Users.Any(u => u.Id == userId))
                .ToListAsync();
        }

        public async Task<Chat> GetChatWithUserDetails(int userId, int targetUserId)
        {
            return await _context.Chats
                .Include(c => c.Users)
                .Where(c => c.Users.Any(u => u.Id == userId) && c.Users.Any(u => u.Id == targetUserId))
                .FirstOrDefaultAsync();
        }


    }

}
