﻿using Microsoft.EntityFrameworkCore;
using Snapspace_DataAccess.Models;
using Snapspace_DataAccess.Repositories.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snapspace_DataAccess.Repositories
{
    public class CommentRepository : ICommentRepository
    {
        private readonly SnapspaceDBContext _context;

        public CommentRepository(SnapspaceDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public int GetCommentCountByPostId(int postId)
        {
            return _context.Comments.Count(c => c.PostId == postId);
        }

        public async Task AddComment(Comment comment)
        {
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
        }

        public async Task<Comment> GetCommentById(int commentId)
        {
            return await _context.Comments.FindAsync(commentId);
        }

        public async Task DeleteComment(Comment comment)
        {
            _context.Comments.Remove(comment);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Comment>> GetRepliesByParentId(int parentId)
        {
            return await _context.Comments
                                 .Where(c => c.ParentCommentId == parentId)
                                 .ToListAsync();
        }

        public async Task UpdateComment(Comment comment)
        {
            _context.Comments.Update(comment);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Comment>> GetCommentsByPostId(int postId)
        {
            return await _context.Comments
                .Where(c => c.PostId == postId && c.ParentCommentId == null)
                .Include(c => c.User)
                .Include(c => c.InverseParentComment)
                    .ThenInclude(r => r.User)
                .ToListAsync();
        }

        public async Task DeleteCommentsByPostId(int postId)
        {
            var comments = await _context.Comments
                .Where(c => c.PostId == postId)
                .ToListAsync();

            if (comments.Any())
            {
                _context.Comments.RemoveRange(comments);
            }
            await _context.SaveChangesAsync();
        }

    }

}
