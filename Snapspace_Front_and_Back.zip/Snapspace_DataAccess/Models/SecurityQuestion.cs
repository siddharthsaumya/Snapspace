﻿using System;
using System.Collections.Generic;

namespace Snapspace_DataAccess.Models
{
    public partial class SecurityQuestion
    {
        public int Id { get; set; }
        public string? Question { get; set; }
    }
}
