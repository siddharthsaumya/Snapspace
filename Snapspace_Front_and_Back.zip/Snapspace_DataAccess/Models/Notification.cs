﻿using System;
using System.Collections.Generic;

namespace Snapspace_DataAccess.Models
{
    public partial class Notification
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public int NotificationType { get; set; }
        public int SourceId { get; set; }
        public DateTime? CreatedAt { get; set; }
        public bool? ReadStatus { get; set; }

        public virtual User? User { get; set; }
    }
}
