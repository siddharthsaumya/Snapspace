﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Snapspace_DataAccess.Models
{
    public partial class Follow
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [ForeignKey("Follower")]
        public int? FollowerId { get; set; }

        [ForeignKey("Following")]
        public int? FollowingId { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; } = DateTime.Now;

        public virtual User? Follower { get; set; }
        public virtual User? Following { get; set; }
    }
}
