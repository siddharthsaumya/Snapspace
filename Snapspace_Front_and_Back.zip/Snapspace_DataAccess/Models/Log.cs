﻿using System;
using System.Collections.Generic;

namespace Snapspace_DataAccess.Models
{
    public partial class Log
    {
        public int Id { get; set; }
        public int? LogType { get; set; }
        public int? UserId { get; set; }
        public string? LogDetails { get; set; }
        public DateTime? CreatedAt { get; set; }

        public virtual User? User { get; set; }
    }
}
