﻿using System;
using System.Collections.Generic;

namespace Snapspace_DataAccess.Models
{
    public partial class FollowRequest
    {
        public int Id { get; set; }
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
        public int Status { get; set; }
        public DateTime? CreatedAt { get; set; }

        public virtual User? FromUser { get; set; }
        public virtual User? ToUser { get; set; }
    }
}
