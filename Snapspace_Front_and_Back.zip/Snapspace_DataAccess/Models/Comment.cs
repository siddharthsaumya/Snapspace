﻿using System;
using System.Collections.Generic;

namespace Snapspace_DataAccess.Models
{
    public partial class Comment
    {
        public Comment()
        {
            InverseParentComment = new HashSet<Comment>();
        }

        public int Id { get; set; }
        public int? PostId { get; set; }
        public int? UserId { get; set; }
        public string? CommentText { get; set; }
        public int? ParentCommentId { get; set; }
        public DateTime? CreatedAt { get; set; }

        public virtual Comment? ParentComment { get; set; }
        public virtual Post? Post { get; set; }
        public virtual User? User { get; set; }
        public virtual ICollection<Comment> InverseParentComment { get; set; }
    }
}
