﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Snapspace_DataAccess.Models
{
    public partial class User
    {
        public User()
        {
            Comments = new HashSet<Comment>();
            FollowFollowers = new HashSet<Follow>();
            FollowFollowings = new HashSet<Follow>();
            FollowRequestFromUsers = new HashSet<FollowRequest>();
            FollowRequestToUsers = new HashSet<FollowRequest>();
            Likes = new HashSet<Like>();
            Logs = new HashSet<Log>();
            Messages = new HashSet<Message>();
            Notifications = new HashSet<Notification>();
            Posts = new HashSet<Post>();
            Chats = new HashSet<Chat>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; } = null!;

        [Required]
        [StringLength(255)]
        public string Password { get; set; } = null!;

        [Required]
        [StringLength(100)]
        public string Email { get; set; } = null!;

        [StringLength(100)]
        public string? FullName { get; set; }

        public string? Bio { get; set; }

        public string? ProfilePicture { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; } = DateTime.Now;

        [Required]
        [Column(TypeName = "bit")]
        public bool? OnlineStatus { get; set; } = false;

        [Required]
        [Column(TypeName = "bit")]
        public bool Active { get; set; } = true;

        public string? SecurityAnswer { get; set; }

        public int? SecurityQuestionId { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }
        public virtual ICollection<Follow> FollowFollowers { get; set; }
        public virtual ICollection<Follow> FollowFollowings { get; set; }
        public virtual ICollection<FollowRequest> FollowRequestFromUsers { get; set; }
        public virtual ICollection<FollowRequest> FollowRequestToUsers { get; set; }
        public virtual ICollection<Like> Likes { get; set; }
        public virtual ICollection<Log> Logs { get; set; }
        public virtual ICollection<Message> Messages { get; set; }
        public virtual ICollection<Notification> Notifications { get; set; }
        public virtual ICollection<Post> Posts { get; set; }
        public virtual ICollection<Chat> Chats { get; set; }
    }
}
